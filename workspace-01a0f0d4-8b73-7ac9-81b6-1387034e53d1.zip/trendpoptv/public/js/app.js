/* ============================================================
   TRENDPOPTV — shared front-end runtime
   (branding, drawer, search, ads, cards, helpers)
   ============================================================ */
window.$ = (s, r = document) => r.querySelector(s);
window.$$ = (s, r = document) => Array.from(r.querySelectorAll(s));
window.S = null;

async function api(path, o = {}) {
  const r = await fetch(path, o);
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'HTTP ' + r.status);
  return d;
}
window.api = api;

window.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
window.fmtViews = (n) => {
  n = +n || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
  return String(n);
};
window.fmtDate = (d) => {
  const t = new Date(d);
  if (isNaN(t)) return String(d || '');
  return t.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

const IC = {
  eye: '<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>',
  cal: '<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4m8-4v4"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l11-6.5Z" fill="#fff"/></svg>',
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 10.5 12 3l9 7.5V21h-6v-6h-6v6H3Z"/></svg>',
  fire: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22c4.4 0 7-2.8 7-6.5 0-4-3-5.5-4-9-2 1.5-2.5 3.5-2 6-1-.5-1.8-1.6-2-3.5C9 10.6 5 12.4 5 16c0 3.4 2.6 6 7 6Z"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3 2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 16.9 6.6 19.8l1.1-6.1L3.2 9.4l6.1-.8Z"/></svg>',
  crown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 8 4 4 5-6 5 6 4-4v9H3Z"/></svg>',
  grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/></svg>',
};
window.IC = IC;

/* video card (shared by home + related) */
window.cardHTML = function (v) {
  return `<a class="card" href="/watch?v=${encodeURIComponent(v.slug)}">
  <div class="thumb">
    <img loading="lazy" src="${esc(v.thumbnail)}" alt="${esc(v.title)}" onerror="this.style.opacity=.12">
    <span class="b-video">VIDEO</span>
    <span class="b-q">${esc(v.quality || '1080p')}</span>
    <span class="play">${IC.play}</span>
    <div class="thumb-foot"><span class="dur">◷ ${esc(v.duration || '0:00')}</span><span class="dots">•••</span></div>
  </div>
  <div class="c-body">
    <h3 title="${esc(v.title)}">${esc(v.title)}</h3>
    <div class="c-meta">
      <span class="vw">${IC.eye}${fmtViews(v.views)}</span>
      <span class="sep">•</span>
      <span class="dt">${IC.cal}${fmtDate(v.date)}</span>
    </div>
  </div></a>`;
};

/* ad slot renderer (AdSense codes only render when enabled in admin) */
window.adHTML = function (key, cls) {
  const z = window.S && S.ads && S.ads.zones ? S.ads.zones[key] : null;
  if (!z || !z.code) return '';
  return `<div class="ad-slot ${cls || ''}"><span class="ad-label">Advertisement</span><div class="ad-body">${z.code}</div></div>`;
};

/* dynamically inserted <script> tags are inert — re-create them so ad code runs */
window.activateScripts = function (root) {
  if (!root) return;
  root.querySelectorAll('script').forEach((old) => {
    if (old.dataset.done) return;
    const s = document.createElement('script');
    for (const a of old.attributes) { if (a.name !== 'data-done') s.setAttribute(a.name, a.value); }
    s.textContent = old.textContent;
    old.replaceWith(s);
  });
};

function logoHTML() {
  const s = S.settings;
  const lt = esc(s.logoText || 'TRENDPOP'), la = esc(s.logoAccent || 'TV');
  return `<svg class="logo-mark" viewBox="0 0 24 24"><defs><linearGradient id="lgm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6d5df6"/><stop offset="1" stop-color="#b04df0"/></linearGradient></defs><rect width="24" height="24" rx="6" fill="url(#lgm)"/><path d="M9.5 7.4v9.2l7.8-4.6Z" fill="#fff"/></svg><span class="logo-txt">${lt}<em>${la}</em></span>`;
}

function brand() {
  const s = S.settings;
  $$('[data-logo]').forEach((el) => (el.innerHTML = logoHTML()));
  $$('[data-tagline]').forEach((el) => (el.textContent = s.tagline || ''));
  $$('[data-copyright]').forEach((el) => (el.textContent = s.footerCopyright || ''));
  $$('[data-disclaimer]').forEach((el) => (el.textContent = s.footerDisclaimer || ''));
  const hn = $('#headerNotice');
  if (hn && s.headerNotice) { hn.textContent = s.headerNotice; hn.hidden = false; }
}

function injectStaticAds() {
  const h = $('#adHeader');
  if (h) { h.innerHTML = adHTML('headerBanner', 'ad-top'); activateScripts(h); }
  const f = $('#adFooter');
  if (f) { f.innerHTML = adHTML('footerTop', 'ad-footer'); activateScripts(f); }
}

/* slide-in drawer */
function wireDrawer() {
  if (!$('#drawerWrap')) return;
  const open = () => document.body.classList.add('nav-open');
  const close = () => document.body.classList.remove('nav-open');
  $('#burger') && $('#burger').addEventListener('click', open);
  $('#drawerClose') && $('#drawerClose').addEventListener('click', close);
  $('#scrim') && $('#scrim').addEventListener('click', close);
  const cats = $('#drawerCats');
  if (cats) {
    cats.innerHTML = S.categories.map((c) =>
      `<a href="/?cat=${encodeURIComponent(c.slug)}"><span>${esc(c.icon || '🎬')}</span>${esc(c.name)}</a>`).join('');
  }
  $$('#drawerWrap a').forEach((a) => a.addEventListener('click', close));
}

/* full-screen search */
function wireSearch() {
  const ov = $('#searchOv');
  if (!ov) return;
  const input = $('#searchInput'), res = $('#searchRes');
  const open = () => { ov.classList.add('open'); document.body.classList.add('lock'); setTimeout(() => input.focus(), 60); };
  const close = () => { ov.classList.remove('open'); document.body.classList.remove('lock'); };
  $('#searchBtn') && $('#searchBtn').addEventListener('click', open);
  $$('.js-search-open').forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); open(); }));
  $('#searchClose') && $('#searchClose').addEventListener('click', close);
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  let t = null, q = '';
  input.addEventListener('input', () => {
    clearTimeout(t);
    q = input.value.trim();
    if (!q) { res.innerHTML = '<div class="sr-hint">Type to search videos…</div>'; return; }
    t = setTimeout(run, 280);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && q) location.href = '/?q=' + encodeURIComponent(q);
  });
  async function run() {
    try {
      const d = await api('/api/videos?limit=8&q=' + encodeURIComponent(q));
      if (!d.videos.length) { res.innerHTML = `<div class="sr-hint">No results for “${esc(q)}”</div>`; return; }
      res.innerHTML = d.videos.map((v) => `<a class="sr-item" href="/watch?v=${encodeURIComponent(v.slug)}"><img src="${esc(v.thumbnail)}" alt=""><span class="sr-t">${esc(v.title)}</span><span class="sr-m">${fmtViews(v.views)} views • ${fmtDate(v.date)}</span></a>`).join('');
      res.querySelectorAll('a').forEach((a) => a.addEventListener('click', close));
    } catch (e) { /* ignore */ }
  }
}

/* toast */
window.toast = function (msg, type) {
  let root = $('#toast');
  if (!root) { root = document.createElement('div'); root.id = 'toast'; document.body.appendChild(root); }
  const t = document.createElement('div');
  t.className = 'toast ' + (type || '');
  t.textContent = msg;
  root.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, 3200);
};

/* boot */
window.appReady = (async () => {
  try {
    window.S = await api('/api/bootstrap');
    brand();
    injectStaticAds();
    wireDrawer();
    wireSearch();
  } catch (e) {
    console.error('Bootstrap failed:', e);
  }
})();
