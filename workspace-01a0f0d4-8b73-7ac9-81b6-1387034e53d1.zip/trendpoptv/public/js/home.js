/* ============================================================
   TRENDPOPTV — home page (tabs, grid, search filter, pagination)
   ============================================================ */
(async function () {
  await window.appReady;

  const qs = new URLSearchParams(location.search);
  const state = {
    sort: qs.get('sort') || 'all',
    page: Math.max(1, +qs.get('page') || 1),
    q: qs.get('q') || '',
    cat: qs.get('cat') || '',
  };

  const grid = $('#grid'), pager = $('#pager');
  const secTitle = $('#secTitle'), secSub = $('#secSub'), secCount = $('#secCount');
  const tabs = $$('.tab');

  const TITLES = {
    all: ['Trending Now', 'Explore videos'],
    trending: ['Trending Now', 'Handpicked for you'],
    latest: ['Latest Videos', 'Fresh uploads'],
    mostviewed: ['Most Viewed', 'All-time popular'],
  };

  function heading() {
    if (state.q) {
      secTitle.textContent = 'Search: "' + state.q + '"';
      secSub.textContent = 'Videos matching your search';
      return;
    }
    if (state.cat) {
      const c = (S.categories || []).find((c) => c.slug === state.cat);
      secTitle.textContent = c ? c.icon + ' ' + c.name : state.cat;
      secSub.textContent = 'Category videos';
      return;
    }
    const t = TITLES[state.sort] || TITLES.all;
    secTitle.textContent = t[0];
    secSub.textContent = t[1];
  }

  function setActiveTab() {
    tabs.forEach((b) => b.classList.toggle('active', b.dataset.tab === state.sort && !state.q && !state.cat));
  }

  function syncUrl() {
    const p = new URLSearchParams();
    if (state.sort !== 'all') p.set('sort', state.sort);
    if (state.page > 1) p.set('page', state.page);
    if (state.q) p.set('q', state.q);
    if (state.cat) p.set('cat', state.cat);
    const s = p.toString();
    history.replaceState(null, '', location.pathname + (s ? '?' + s : ''));
  }

  tabs.forEach((b) => b.addEventListener('click', () => {
    state.sort = b.dataset.tab;
    state.page = 1;
    state.q = '';
    state.cat = '';
    load();
  }));

  function skeleton() {
    grid.innerHTML = Array.from({ length: 8 })
      .map(() => '<div class="skel"><div class="sk"></div><div class="sk t1"></div><div class="sk t2"></div></div>')
      .join('');
  }

  async function load() {
    heading(); setActiveTab(); syncUrl(); skeleton(); pager.innerHTML = '';
    const p = new URLSearchParams({ sort: state.sort, page: state.page, limit: (S.settings && S.settings.videosPerPage) || 20 });
    if (state.q) p.set('q', state.q);
    if (state.cat) p.set('cat', state.cat);
    try {
      const d = await api('/api/videos?' + p);
      secCount.textContent = d.total + ' video' + (d.total === 1 ? '' : 's');
      if (!d.videos.length) {
        grid.innerHTML = '<div class="empty">😕 No videos found. Try another search, category or filter.</div>';
        return;
      }
      let html = '';
      d.videos.forEach((v, i) => {
        html += cardHTML(v);
        if (i === 7) html += adHTML('homeMid', 'ad-infeed');
      });
      grid.innerHTML = html;
      activateScripts(grid);
      renderPager(d.pages, d.page);
    } catch (e) {
      grid.innerHTML = '<div class="empty">⚠️ Failed to load videos. Please refresh and try again.</div>';
    }
  }

  function renderPager(pages, cur) {
    if (pages <= 1) { pager.innerHTML = ''; return; }
    let start = Math.max(1, Math.min(cur - 2, pages - 4));
    let end = Math.min(pages, start + 4);
    start = Math.max(1, end - 4);
    let html = `<button data-p="${cur - 1}" ${cur === 1 ? 'disabled' : ''}>‹</button>`;
    for (let i = start; i <= end; i++) html += `<button data-p="${i}" class="${i === cur ? 'on' : ''}">${i}</button>`;
    html += `<button data-p="${cur + 1}" ${cur === pages ? 'disabled' : ''}>›</button>`;
    pager.innerHTML = html;
  }

  pager.addEventListener('click', (e) => {
    const b = e.target.closest('[data-p]');
    if (!b || b.disabled) return;
    state.page = +b.dataset.p;
    load();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  load();
})();
