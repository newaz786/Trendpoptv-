/* ============================================================
   TRENDPOPTV — static pages (About / Contact / Privacy / Terms …)
   ============================================================ */
(async function () {
  await window.appReady;

  const slug = new URLSearchParams(location.search).get('p') || 'about';
  let pg = null;
  try {
    pg = await api('/api/page/' + encodeURIComponent(slug));
  } catch (e) { /* handled below */ }

  const t = $('#pageTitle'), b = $('#pageBody');

  if (!pg) {
    t.textContent = 'Page Not Found';
    b.innerHTML = '<p>Sorry, the page you are looking for does not exist. <a href="/">← Go back home</a></p>';
    return;
  }

  t.textContent = pg.title;
  document.title = pg.title + ' — ' + ((S.settings && S.settings.siteName) || 'TRENDPOPTV');
  b.innerHTML = pg.content || '<p>Content coming soon.</p>';
  activateScripts(b);

  if (slug === 'contact') {
    $('#contactWrap').hidden = false;
    $('#contactEmail').textContent = (S.settings && S.settings.contactEmail) || 'support@trendpoptv.com';
    const f = $('#cf'), note = $('#cfNote');
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      note.textContent = 'Sending…';
      note.className = 'cf-note';
      const body = {
        name: $('#cfName').value.trim(),
        email: $('#cfEmail').value.trim(),
        message: $('#cfMsg').value.trim(),
      };
      try {
        const r = await api('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        note.textContent = '✅ ' + (r.message || 'Message sent successfully!');
        note.classList.add('ok');
        f.reset();
      } catch (err) {
        note.textContent = '⚠️ ' + err.message;
        note.classList.add('err');
      }
    });
  }
})();
