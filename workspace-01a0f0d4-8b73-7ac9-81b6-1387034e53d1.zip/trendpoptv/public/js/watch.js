/* ============================================================
   TRENDPOPTV — watch page (custom player, info, pics, related)
   ============================================================ */
(async function () {
  await window.appReady;

  const slug = new URLSearchParams(location.search).get('v');
  if (!slug) return showErr('No video selected. Please pick a video from the home page.');

  let data;
  try {
    data = await api('/api/video/' + encodeURIComponent(slug));
  } catch (e) {
    return showErr('Video not found or unavailable.');
  }

  const v = data.video;
  const related = data.related || [];

  /* ---- text content ---- */
  document.title = (v.seoTitle || v.title) + ' — ' + ((S.settings && S.settings.siteName) || 'TRENDPOPTV');
  $('#vTitle').textContent = v.title;
  $('#vQuality').textContent = (v.quality && /4k/i.test(v.quality) ? '4K Ultra HD' : 'Full HD ' + (v.quality || '1080p'));
  $('#relDate').textContent = fmtDate(v.date);
  $('#viewsL').innerHTML = IC.eye + ' <b>' + fmtViews((v.views || 0) + 1) + '</b>&nbsp;Views';

  const notice = (S.settings && S.settings.playerNotice) || '';
  if (notice) $('#adNotice').textContent = notice;
  else $('#adNotice').style.display = 'none';

  if (v.description) {
    $('#descRow').hidden = false;
    $('#descText').textContent = v.description;
  }

  /* ---- pictures ---- */
  if (v.images && v.images.length) {
    $('#picSec').hidden = false;
    $('#picCount').textContent = '(' + v.images.length + ' image' + (v.images.length > 1 ? 's' : '') + ')';
    $('#picGrid').innerHTML = v.images.map((u) =>
      `<a class="pic" href="${esc(u)}" target="_blank" rel="noopener"><img loading="lazy" src="${esc(u)}" alt="${esc(v.title)}"></a>`
    ).join('');
  }

  /* ---- related ---- */
  $('#relCount').textContent = related.length;
  $('#relGrid').innerHTML = related.length
    ? related.map(cardHTML).join('')
    : '<div class="empty">No related videos yet.</div>';

  /* ---- ad zones ---- */
  const abp = $('#adBelowPlayer');
  abp.innerHTML = adHTML('belowPlayer', 'ad-watch');
  activateScripts(abp);
  const aar = $('#adAfterRelated');
  aar.innerHTML = adHTML('afterRelated', 'ad-watch');
  activateScripts(aar);

  /* ---- player ---- */
  if (v.videoType === 'youtube') buildYT(v.videoUrl);
  else buildMP4(v.videoUrl);

  /* ---- count the view ---- */
  fetch('/api/video/' + encodeURIComponent(slug) + '/view', { method: 'POST' }).catch(() => {});

  /* ============================================================ */
  function showErr(m) {
    $('#watchMain').innerHTML =
      `<div class="empty big">⚠️ ${esc(m)}<br><a class="btn" href="/">← Back to Home</a></div>`;
  }

  function ytId(u) {
    const m = String(u || '').match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{6,})/);
    if (m) return m[1];
    return /^[\w-]{11}$/.test(u) ? u : '';
  }

  function buildYT(u) {
    const id = ytId(u);
    const p = $('#player');
    if (!id) { p.innerHTML = '<div class="empty">Invalid YouTube URL</div>'; return; }
    p.classList.add('yt');
    p.innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1" title="${esc(v.title)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`;
  }

  function buildMP4(u) {
    const vid = $('#vid'), tap = $('#tap'), big = $('#bigPlay');
    const fill = $('#fill'), prog = $('#prog'), tl = $('#timeLabel');
    const vol = $('#volRange'), volBtn = $('#volBtn'), fs = $('#fsBtn');
    const setBtn = $('#setBtn'), setMenu = $('#setMenu'), player = $('#player');

    if (u) vid.src = u;
    tl.textContent = '0:00 / ' + (v.duration || '0:00');

    const fmtT = (s) => {
      if (!isFinite(s)) return '0:00';
      s = Math.floor(s);
      return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
    };
    function tick() {
      const d = vid.duration || 0, c = vid.currentTime || 0;
      fill.style.width = (d ? (c / d) * 100 : 0) + '%';
      tl.textContent = fmtT(c) + ' / ' + fmtT(d);
    }
    vid.addEventListener('timeupdate', tick);
    vid.addEventListener('loadedmetadata', tick);

    const toggle = () => (vid.paused ? vid.play() : vid.pause());
    big.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });
    tap.addEventListener('click', toggle);
    vid.addEventListener('click', toggle);
    vid.addEventListener('play', () => tap.classList.add('hide'));
    vid.addEventListener('pause', () => tap.classList.remove('hide'));
    vid.addEventListener('ended', () => tap.classList.remove('hide'));
    vid.addEventListener('error', () => {
      if (vid.error) toast('Could not load this video source.', 'err');
    });

    prog.addEventListener('click', (e) => {
      const r = prog.getBoundingClientRect();
      const pct = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      if (isFinite(vid.duration)) vid.currentTime = pct * vid.duration;
    });

    vol.addEventListener('input', () => {
      vid.volume = +vol.value;
      vid.muted = +vol.value === 0;
      volBtn.textContent = vid.muted ? '🔇' : '🔊';
    });
    volBtn.addEventListener('click', () => {
      vid.muted = !vid.muted;
      volBtn.textContent = vid.muted ? '🔇' : '🔊';
      if (!vid.muted && vid.volume === 0) { vid.volume = 0.5; vol.value = 0.5; }
    });

    fs.addEventListener('click', () => {
      if (document.fullscreenElement) document.exitFullscreen();
      else if (player.requestFullscreen) player.requestFullscreen();
      else if (vid.webkitEnterFullscreen) vid.webkitEnterFullscreen();
    });

    setBtn.addEventListener('click', (e) => { e.stopPropagation(); setMenu.hidden = !setMenu.hidden; });
    document.addEventListener('click', () => { if (!setMenu.hidden) setMenu.hidden = true; });
    setMenu.querySelectorAll('[data-speed]').forEach((b) =>
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        vid.playbackRate = +b.dataset.speed;
        setMenu.querySelectorAll('[data-speed]').forEach((x) => x.classList.toggle('on', x === b));
      })
    );
    const loopBtn = $('#loopBtn');
    if (loopBtn) loopBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      vid.loop = !vid.loop;
      loopBtn.textContent = '🔁 ' + (vid.loop ? 'On' : 'Off');
      loopBtn.classList.toggle('on', vid.loop);
    });

    document.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.code === 'Space') { e.preventDefault(); toggle(); }
      if (e.key === 'ArrowRight') vid.currentTime += 10;
      if (e.key === 'ArrowLeft') vid.currentTime -= 10;
      if (e.key === 'f') fs.click();
      if (e.key === 'm') volBtn.click();
    });
  }
})();
