'use strict';
/*
 * ============================================================
 *  TRENDPOPTV — Video Streaming Platform
 *  Zero-dependency Node.js server
 *  - Public website (home / watch / pages)
 *  - JSON API
 *  - Admin Panel API (videos, categories, ads, pages, messages, settings)
 *  - SEO meta injection, sitemap.xml, robots.txt, ads.txt
 * ============================================================
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const ADMIN_DIR = path.join(ROOT, 'admin');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

/* ------------------------------ utils ------------------------------ */
const uid = () => crypto.randomBytes(8).toString('hex');
const nowISO = () => new Date().toISOString();
const sha = (p) => crypto.createHash('sha256').update(String(p)).digest('hex');
const htmlEsc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const xmlEsc = htmlEsc;
function slugify(s) {
  const t = String(s || '').toLowerCase().replace(/[^a-z0-9\s-]/g, '').trim().replace(/[\s-]+/g, '-').slice(0, 60);
  return t || 'video-' + uid().slice(0, 6);
}

/* timing-safe string compare (prevents password timing attacks) */
function safeEq(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

/* brute-force protection for admin login (in-memory, per-IP) */
const loginAttempts = new Map(); // ip -> { count, resetAt, lockedUntil }
const LOGIN_MAX_TRIES = 8;       // attempts allowed per window
const LOGIN_WINDOW_MS = 10 * 60e3; // 10-minute window
const LOGIN_LOCK_MS = 10 * 60e3;   // 10-minute lockout after too many failures

/* --------------------------- seed database -------------------------- */
function seedDB() {
  const cats = [
    { id: uid(), name: 'Entertainment', slug: 'entertainment', icon: '🎬' },
    { id: uid(), name: 'Music', slug: 'music', icon: '🎵' },
    { id: uid(), name: 'Comedy', slug: 'comedy', icon: '😂' },
    { id: uid(), name: 'Vlogs', slug: 'vlogs', icon: '📹' },
    { id: uid(), name: 'Tech', slug: 'tech', icon: '📱' },
    { id: uid(), name: 'Sports', slug: 'sports', icon: '⚽' },
  ];

  // Public sample videos (Google open video bucket) — perfect for testing/demo
  const SRC = [
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', '9:56'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', '10:53'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', '1:00'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', '0:15'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4', '0:15'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4', '0:15'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4', '0:15'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4', '14:48'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4', '12:14'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4', '9:54'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4', '10:53'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4', '0:47'],
    ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4', '9:24'],
  ];

  const DEFS = [
    ['Must Watch 💥', 'entertainment', 1], ['Best Moments 💞', 'vlogs', 1],
    ['Trending Hit 🔥', 'music', 1], ['Viral Today ⚡', 'entertainment', 1],
    ['Comedy Special 😂', 'comedy', 1], ['Travel Vlog 🌍', 'vlogs', 0],
    ['Music Mashup 🎵', 'music', 1], ['Street Food Tour 🍜', 'vlogs', 0],
    ['Tech Review 📱', 'tech', 0], ['Game Highlights 🎮', 'sports', 0],
    ['Dance Cover 💃', 'music', 0], ['Daily Vlog 📹', 'vlogs', 0],
    ['Must Watch 💥', 'entertainment', 0], ['Behind The Scenes 🎬', 'entertainment', 0],
    ['Top 10 Countdown 🏆', 'entertainment', 1], ['Reaction Video 😲', 'comedy', 0],
    ['Cooking Show 🍳', 'vlogs', 0], ['Fitness Challenge 💪', 'sports', 0],
    ['Movie Trailer 🎥', 'entertainment', 1], ['Sports Recap ⚽', 'sports', 0],
    ['Gadget Unboxing 📦', 'tech', 0], ['Funny Clips 🤣', 'comedy', 0],
    ['Live Session 🎤', 'music', 1], ['Weekend Special 🌟', 'entertainment', 0],
  ];
  const VIEWS = [29400, 35200, 34200, 25000, 37300, 20700, 14300, 38100, 32500, 12800, 26600, 14600, 45700, 45500, 13700, 45300, 23800, 33300, 17500, 52100, 18900, 27400, 41500, 16200];

  const videos = DEFS.map((d, i) => {
    const title = d[0], cat = d[1], trending = !!d[2];
    const src = SRC[i % SRC.length];
    const day = 30 - Math.floor(i / 3);
    const date = '2026-09-' + String(day).padStart(2, '0');
    const id = uid();
    return {
      id,
      slug: slugify(title + '-' + (i + 1)),
      title,
      description: title + ' — now streaming on TRENDPOPTV in Full HD. Fresh ' + cat + ' entertainment, updated daily: watch trending, viral and must-watch clips from around the world. Tap play, enjoy the show and explore related videos below.',
      category: cat,
      tags: ['trending', 'viral', cat, '2026'],
      videoType: 'mp4',
      videoUrl: src[0],
      thumbnail: 'https://picsum.photos/seed/tp' + (i + 1) + '/640/360',
      duration: src[1],
      quality: '1080p',
      date,
      views: VIEWS[i],
      status: 'published',
      trending,
      featured: i % 5 === 0,
      images: ['https://picsum.photos/seed/tpp' + (i + 1) + '/720/960'],
      seoTitle: '',
      seoDescription: '',
      createdAt: nowISO(),
      updatedAt: nowISO(),
    };
  });

  const pages = {
    about: {
      title: 'About Us',
      content: `<h3>Welcome to TRENDPOPTV</h3>
<p>TRENDPOPTV is a free video streaming and discovery platform built for entertainment lovers. We curate trending, viral and must-watch videos from across the web and present them in one clean, fast and easy-to-use place.</p>
<h3>What We Offer</h3>
<ul>
<li>Hand-picked trending videos, updated daily</li>
<li>Fast, mobile-friendly Full HD streaming</li>
<li>Simple discovery — no sign-up required</li>
<li>Curated categories: entertainment, music, comedy, vlogs, tech and sports</li>
</ul>
<h3>Our Mission</h3>
<p>Our goal is to make discovering great videos effortless. We do not host any video files on our servers — all content is streamed from third-party sources and belongs to its respective owners. If you are a copyright holder, please see our <a href="/page?p=dmca">DMCA page</a>.</p>`,
    },
    contact: {
      title: 'Contact Us',
      content: `<p>Have a question, feedback, a content request or a copyright concern? We'd love to hear from you. Send us a message using the form below and our team will get back to you within 24–48 hours.</p>
<p>You can also email us directly at <b>support@trendpoptv.com</b>.</p>`,
    },
    'privacy-policy': {
      title: 'Privacy Policy',
      content: `<p><em>Last updated: September 30, 2026</em></p>
<p>Welcome to TRENDPOPTV ("we", "our", "us"). Your privacy is important to us. This Privacy Policy explains what information we collect when you visit TRENDPOPTV, how we use it, and the choices you have. By using this website you agree to the practices described in this policy.</p>
<h3>1. Information We Collect</h3>
<ul>
<li><b>Usage Data:</b> pages visited, videos watched, time spent, browser type, device type and referring pages. This data is aggregated and is not used to personally identify you.</li>
<li><b>Contact Information:</b> if you contact us through our form or by email, we receive your name, email address and the contents of your message.</li>
<li><b>Cookies:</b> small files stored on your device that help the site remember preferences and help our advertising partners serve relevant ads.</li>
</ul>
<h3>2. Cookies, Web Beacons and Google AdSense</h3>
<p>We use third-party advertising companies, including Google AdSense, to serve ads when you visit our website. These companies may use information (not including your name, address, email address or telephone number) about your visits to this and other websites in order to provide advertisements about goods and services of interest to you.</p>
<ul>
<li>Google, as a third-party vendor, uses cookies (including the DART cookie) to serve ads on our site based on your prior visits.</li>
<li>You may opt out of personalized advertising by visiting Google Ads Settings: https://www.google.com/settings/ads</li>
<li>You can learn more about how Google uses data at: https://policies.google.com/technologies/ads</li>
</ul>
<h3>3. Log Files</h3>
<p>Like many websites, we use log files. The information inside the log files includes internet protocol (IP) addresses, browser type, internet service provider (ISP), date/time stamp, referring/exit pages and number of clicks. This information is used to analyze trends, administer the site and gather demographic information. It is not linked to any information that is personally identifiable.</p>
<h3>4. How We Use Your Information</h3>
<p>We use the information we collect to operate and improve the website, respond to inquiries, monitor and analyze usage, and keep the service safe and free of abuse.</p>
<h3>5. Third-Party Websites</h3>
<p>TRENDPOPTV embeds or links to content hosted by third-party platforms. We are not responsible for the privacy practices of those sites and encourage you to read their privacy policies.</p>
<h3>6. Children's Information</h3>
<p>We do not knowingly collect any personally identifiable information from children under the age of 13. If you believe your child has provided such information, please contact us and we will promptly remove it.</p>
<h3>7. Data Security</h3>
<p>We take reasonable measures to protect your information. However, no method of transmission over the internet is 100% secure and we cannot guarantee absolute security.</p>
<h3>8. Changes to This Policy</h3>
<p>We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated revision date.</p>
<h3>9. Contact Us</h3>
<p>If you have any questions about this Privacy Policy, contact us at <b>support@trendpoptv.com</b>.</p>`,
    },
    terms: {
      title: 'Terms of Service',
      content: `<p><em>Last updated: September 30, 2026</em></p>
<p>Welcome to TRENDPOPTV. By accessing or using this website you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please do not use the website.</p>
<h3>1. Description of Service</h3>
<p>TRENDPOPTV is a video streaming and discovery platform that curates and presents video content from third-party sources for promotional and entertainment purposes. We do not host, upload or store any video files on our own servers.</p>
<h3>2. Acceptable Use</h3>
<ul>
<li>You agree to use the site for lawful, personal and non-commercial purposes only.</li>
<li>You will not attempt to disrupt, reverse-engineer, overload or abuse the service or its infrastructure.</li>
<li>You will not scrape, harvest or republish content in bulk without written permission.</li>
</ul>
<h3>3. Intellectual Property</h3>
<p>All videos, thumbnails and images remain the property of their respective copyright holders. They are presented for promotional purposes only. If you are a rights holder and believe content infringes your copyright, please follow the procedure on our <a href="/page?p=dmca">DMCA page</a>. The TRENDPOPTV name, logo and website design are the property of TRENDPOPTV.</p>
<h3>4. Advertisements</h3>
<p>This service is supported by advertising. Ads are provided by third-party networks (such as Google AdSense) and we are not responsible for the content of any advertisement or the products and services they promote.</p>
<h3>5. Third-Party Links</h3>
<p>Our website may contain links or embeds to third-party websites. We have no control over, and assume no responsibility for, their content, privacy policies or practices.</p>
<h3>6. Disclaimer of Warranties</h3>
<p>The service is provided "as is" and "as available" without warranties of any kind, either express or implied, including but not limited to accuracy, availability and fitness for a particular purpose.</p>
<h3>7. Limitation of Liability</h3>
<p>In no event shall TRENDPOPTV or its team be liable for any indirect, incidental, special or consequential damages arising out of or in connection with your use of the website.</p>
<h3>8. Changes to the Terms</h3>
<p>We may revise these Terms at any time. Continued use of the website after changes are posted constitutes acceptance of the new terms.</p>
<h3>9. Contact</h3>
<p>Questions about these Terms? Email <b>support@trendpoptv.com</b>.</p>`,
    },
    dmca: {
      title: 'DMCA — Copyright Policy',
      content: `<p><em>Last updated: September 30, 2026</em></p>
<p>TRENDPOPTV respects the intellectual property rights of others and expects its users to do the same. We comply with the Digital Millennium Copyright Act (DMCA) and respond promptly to valid copyright infringement notices.</p>
<p><b>Important:</b> TRENDPOPTV does not host any video files on its servers. All media is streamed from third-party sources. If you wish to remove content permanently, please also contact the hosting source. We can remove the listing/link from TRENDPOPTV upon a valid request.</p>
<h3>Filing a DMCA Takedown Notice</h3>
<p>To request removal of content from TRENDPOPTV, please email us at <b>dmca@trendpoptv.com</b> with the following information:</p>
<ol>
<li>Your full name, address, telephone number and email address.</li>
<li>A clear description of the copyrighted work you claim has been infringed.</li>
<li>The exact URL(s) on TRENDPOPTV where the material appears.</li>
<li>A statement that you have a good-faith belief that the use of the material is not authorized by the copyright owner, its agent or the law.</li>
<li>A statement, made under penalty of perjury, that the information in your notice is accurate and that you are the copyright owner or authorized to act on the owner's behalf.</li>
<li>Your physical or electronic signature (typing your full name is sufficient).</li>
</ol>
<h3>What Happens Next</h3>
<p>Once we receive a complete and valid notice, we will remove or disable access to the listed content — usually within 24–72 hours — and notify the party that provided it.</p>
<h3>Counter-Notification</h3>
<p>If you believe content was removed in error, you may send a counter-notice to <b>dmca@trendpoptv.com</b> including your contact details, identification of the removed content, a statement under penalty of perjury that the removal was a mistake, and your consent to the jurisdiction of your local courts.</p>
<h3>Repeat Infringers</h3>
<p>We reserve the right to block access to repeat infringing material and to terminate relationships with sources that repeatedly infringe copyrights.</p>`,
    },
    disclaimer: {
      title: 'Disclaimer',
      content: `<p><em>Last updated: September 30, 2026</em></p>
<p>All information and content on TRENDPOPTV is published in good faith and for general information and entertainment purposes only. We make no representation or warranty of any kind regarding the accuracy, adequacy, validity, reliability or completeness of any information on the site.</p>
<h3>No Hosting of Files</h3>
<p>TRENDPOPTV does not host, store or upload any video or media files on its servers. All videos are streamed from third-party sources that are publicly available. All trademarks and copyrights belong to their respective owners.</p>
<h3>External Links Disclaimer</h3>
<p>The site may contain links to external websites. We do not investigate, monitor or endorse the content, accuracy or opinions expressed on such websites and we are not responsible for them.</p>
<h3>Advertising Disclaimer</h3>
<p>Some sections of this website display advertisements served by third-party networks, including Google AdSense, which may use cookies to personalize ads. We do not control the content of these advertisements.</p>
<h3>Fair Use</h3>
<p>Content presented on this website is for promotional and discovery purposes. If you are a copyright holder and want content removed, please see our <a href="/page?p=dmca">DMCA page</a> — requests are honored promptly.</p>
<p>By using our website you hereby consent to this disclaimer and agree to its terms.</p>`,
    },
  };

  return {
    settings: {
      siteName: 'TRENDPOPTV',
      logoText: 'TRENDPOP',
      logoAccent: 'TV',
      tagline: 'Official premium video streaming and discovery platform. Watch trending videos from around the world.',
      contactEmail: 'support@trendpoptv.com',
      headerNotice: '',
      playerNotice: '⚠️ If an ad appears, press Back and tap Play again.',
      videosPerPage: 20,
      footerCopyright: '© 2026 TRENDPOPTV. All rights reserved.',
      footerDisclaimer: 'All videos are owned by their respective copyright holders and are used for promotional purposes only. We do not host any videos on our servers.',
      adminPasswordHash: sha('admin123'),
      seo: {
        title: 'TRENDPOPTV — Watch Trending Videos Online',
        description: 'TRENDPOPTV is a free video streaming and discovery platform. Watch trending, viral and must-watch videos in Full HD — entertainment, music, comedy, vlogs and more.',
        keywords: 'videos, streaming, trending videos, viral videos, watch online, TRENDPOPTV',
        ogImage: '',
      },
    },
    categories: cats,
    videos,
    ads: {
      adsensePublisherId: '',
      headSnippet: '',
      adsTxt: '',
      zones: {
        headerBanner: { label: 'Header Banner (all pages)', enabled: false, code: '' },
        homeMid: { label: 'Home Feed — after 8 videos', enabled: false, code: '' },
        belowPlayer: { label: 'Watch Page — below player', enabled: false, code: '' },
        afterRelated: { label: 'Watch Page — after related videos', enabled: false, code: '' },
        footerTop: { label: 'Above Footer (all pages)', enabled: false, code: '' },
      },
    },
    pages,
    messages: [],
    sessions: {},
  };
}

/* ---------------------------- db load/save --------------------------- */
let db;
function loadDB() {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(DB_FILE)) {
      db = seedDB();
      fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
      console.log('✔ Seeded fresh database at data/db.json');
      return;
    }
    db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (e) {
    console.error('DB load failed, reseeding:', e.message);
    db = seedDB();
  }
}
function saveDB() {
  try { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
  catch (e) { console.error('DB save failed:', e.message); }
}
loadDB();

/* ------------------------------ helpers ------------------------------ */
function publicSettings() {
  const s = Object.assign({}, db.settings);
  delete s.adminPasswordHash;
  return s;
}
function enrich(v) {
  const c = db.categories.find((c) => c.slug === v.category);
  return Object.assign({}, v, { categoryName: c ? c.name : v.category, categoryIcon: c ? c.icon : '🎬' });
}
function uniqueSlug(base, ignoreId) {
  let s = slugify(base), i = 2;
  while (db.videos.some((v) => v.slug === s && v.id !== ignoreId)) { s = slugify(base) + '-' + i; i++; }
  return s;
}
function authToken(req) {
  const a = req.headers.authorization || '';
  const t = a.startsWith('Bearer ') ? a.slice(7) : '';
  const s = t && db.sessions[t];
  if (!s) return null;
  if (s.expires < Date.now()) { delete db.sessions[t]; saveDB(); return null; }
  s.expires = Date.now() + 7 * 864e5;
  return t;
}
function cleanVideo(b, v) {
  b = b || {}; v = v || {};
  v.title = String(b.title ?? v.title ?? '').trim().slice(0, 200);
  v.description = String(b.description ?? v.description ?? '').slice(0, 5000);
  v.category = String(b.category ?? v.category ?? '').slice(0, 60);
  if (Array.isArray(b.tags)) v.tags = b.tags.map((t) => String(t).slice(0, 40)).filter(Boolean).slice(0, 20);
  else if (typeof b.tags === 'string') v.tags = b.tags.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 20);
  else v.tags = v.tags || [];
  v.videoType = b.videoType === 'youtube' ? 'youtube' : 'mp4';
  v.videoUrl = String(b.videoUrl ?? v.videoUrl ?? '').trim();
  v.thumbnail = String(b.thumbnail ?? v.thumbnail ?? '').trim();
  v.duration = String(b.duration ?? v.duration ?? '').slice(0, 10);
  v.quality = String(b.quality ?? v.quality ?? '1080p').slice(0, 10) || '1080p';
  v.date = String(b.date ?? v.date ?? nowISO().slice(0, 10)).slice(0, 10);
  v.views = Number.isFinite(+b.views) ? Math.max(0, Math.round(+b.views)) : (v.views || 0);
  v.status = b.status === 'draft' ? 'draft' : 'published';
  v.trending = !!b.trending;
  v.featured = !!b.featured;
  v.images = Array.isArray(b.images) ? b.images.map((s) => String(s).trim()).filter(Boolean).slice(0, 20) : (v.images || []);
  v.seoTitle = String(b.seoTitle ?? v.seoTitle ?? '').slice(0, 200);
  v.seoDescription = String(b.seoDescription ?? v.seoDescription ?? '').slice(0, 300);
  return v;
}

/* ------------------------------ routing ------------------------------ */
const routes = [];
function route(method, pattern, handler, admin) {
  const names = [];
  const parts = pattern.split('/').map((seg) => {
    if (seg.startsWith(':')) { names.push(seg.slice(1)); return '([^/]+)'; }
    return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  });
  routes.push({ method, rx: new RegExp('^' + parts.join('/') + '$'), names, handler, admin: !!admin });
}
function json(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(b);
}
function text(res, code, body, type) {
  res.writeHead(code, { 'Content-Type': type || 'text/plain; charset=utf-8' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => { d += c; if (d.length > 3e6) { reject(new Error('too large')); req.destroy(); } });
    req.on('end', () => resolve(d));
    req.on('error', reject);
  });
}

/* --------------------------- public API ------------------------------ */
route('GET', '/api/bootstrap', (req, res) => {
  const zones = {};
  for (const k in db.ads.zones) {
    const z = db.ads.zones[k];
    if (z.enabled && z.code) zones[k] = { label: z.label, code: z.code };
  }
  json(res, 200, {
    settings: publicSettings(),
    categories: db.categories,
    ads: { zones, adsensePublisherId: db.ads.adsensePublisherId || '' },
    counts: { videos: db.videos.filter((v) => v.status === 'published').length },
  });
});

route('GET', '/api/videos', (req, res, p, sp) => {
  let vids = db.videos.filter((v) => v.status === 'published');
  const q = (sp.get('q') || '').toLowerCase().trim();
  const cat = (sp.get('cat') || '').trim();
  if (q) vids = vids.filter((v) => (v.title + ' ' + v.description + ' ' + (v.tags || []).join(' ')).toLowerCase().includes(q));
  if (cat) vids = vids.filter((v) => v.category === cat);
  const sort = sp.get('sort') || 'all';
  if (sort === 'trending') vids.sort((a, b) => ((b.trending ? 1 : 0) - (a.trending ? 1 : 0)) || b.views - a.views);
  else if (sort === 'mostviewed') vids.sort((a, b) => b.views - a.views);
  else vids.sort((a, b) => new Date(b.date) - new Date(a.date));
  const total = vids.length;
  const limit = Math.min(Math.max(1, +(sp.get('limit')) || db.settings.videosPerPage || 20), 100);
  const page = Math.max(1, +(sp.get('page')) || 1);
  json(res, 200, { videos: vids.slice((page - 1) * limit, page * limit).map(enrich), total, page, pages: Math.max(1, Math.ceil(total / limit)), limit });
});

route('GET', '/api/video/:slug', (req, res, p) => {
  const v = db.videos.find((x) => (x.slug === p.slug || x.id === p.slug) && x.status === 'published');
  if (!v) return json(res, 404, { error: 'Video not found' });
  const pub = db.videos.filter((x) => x.status === 'published' && x.id !== v.id);
  const same = pub.filter((x) => x.category === v.category).sort((a, b) => b.views - a.views);
  const rest = pub.filter((x) => x.category !== v.category).sort((a, b) => b.views - a.views);
  const related = same.concat(rest).slice(0, 8).map(enrich);
  json(res, 200, { video: enrich(v), related });
});

route('POST', '/api/video/:slug/view', (req, res, p) => {
  const v = db.videos.find((x) => x.slug === p.slug || x.id === p.slug);
  if (!v) return json(res, 404, { error: 'Not found' });
  v.views = (v.views || 0) + 1;
  saveDB();
  json(res, 200, { ok: true, views: v.views });
});

route('GET', '/api/page/:slug', (req, res, p) => {
  const pg = db.pages[p.slug];
  if (!pg) return json(res, 404, { error: 'Page not found' });
  json(res, 200, { slug: p.slug, title: pg.title, content: pg.content });
});

route('POST', '/api/contact', (req, res, p, sp, b) => {
  const name = String((b && b.name) || '').trim().slice(0, 120);
  const email = String((b && b.email) || '').trim().slice(0, 160);
  const message = String((b && b.message) || '').trim().slice(0, 3000);
  if (!name || !/^\S+@\S+\.\S+$/.test(email) || !message)
    return json(res, 400, { error: 'Please fill in all fields with a valid email address.' });
  db.messages.unshift({ id: uid(), name, email, message, date: nowISO(), read: false });
  saveDB();
  json(res, 200, { ok: true, message: 'Thanks! Your message has been received. We usually reply within 24–48 hours.' });
});

/* ---------------------------- admin API ------------------------------ */
route('POST', '/api/admin/login', async (req, res, p, sp, b) => {
  const ip = (String(req.headers['x-forwarded-for'] || '').split(',')[0] || req.socket.remoteAddress || 'unknown').trim();
  const nowTs = Date.now();

  let rec = loginAttempts.get(ip);
  if (rec && rec.resetAt < nowTs) { loginAttempts.delete(ip); rec = null; }
  if (rec && rec.lockedUntil && rec.lockedUntil > nowTs) {
    const mins = Math.ceil((rec.lockedUntil - nowTs) / 60000);
    return json(res, 429, { error: 'Too many failed attempts. Login is locked — try again in ' + mins + ' minute' + (mins > 1 ? 's' : '') + '.' });
  }

  const pass = String((b && b.password) || '');
  const ok = safeEq(sha(pass), db.settings.adminPasswordHash);

  if (!ok) {
    rec = rec || { count: 0, resetAt: nowTs + LOGIN_WINDOW_MS, lockedUntil: 0 };
    rec.count += 1;
    if (rec.count >= LOGIN_MAX_TRIES) {
      rec.lockedUntil = nowTs + LOGIN_LOCK_MS;
      rec.count = 0;
      rec.resetAt = rec.lockedUntil;
    }
    loginAttempts.set(ip, rec);
    await new Promise((r) => setTimeout(r, 700)); // slow down brute force
    return json(res, 401, { error: 'Incorrect password. Please try again.' });
  }

  // success — clear attempts, prune expired sessions, issue token
  loginAttempts.delete(ip);
  for (const t in db.sessions) if (db.sessions[t].expires < nowTs) delete db.sessions[t];
  const t = crypto.randomBytes(24).toString('hex');
  db.sessions[t] = { created: nowTs, expires: nowTs + 7 * 864e5 };
  saveDB();
  json(res, 200, { ok: true, token: t });
});

route('POST', '/api/admin/logout', (req, res) => {
  const t = authToken(req);
  if (t) { delete db.sessions[t]; saveDB(); }
  json(res, 200, { ok: true });
}, true);

route('GET', '/api/admin/stats', (req, res) => {
  const pub = db.videos.filter((v) => v.status === 'published');
  json(res, 200, {
    videos: { total: db.videos.length, published: pub.length, drafts: db.videos.length - pub.length },
    views: db.videos.reduce((a, v) => a + (v.views || 0), 0),
    categories: db.categories.length,
    messages: { total: db.messages.length, unread: db.messages.filter((m) => !m.read).length },
    recent: db.videos.slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 6),
  });
}, true);

route('GET', '/api/admin/videos', (req, res, p, sp) => {
  let vids = db.videos.slice().sort((a, b) => new Date(b.date) - new Date(a.date));
  const q = (sp.get('q') || '').toLowerCase().trim();
  const status = sp.get('status') || '';
  if (q) vids = vids.filter((v) => (v.title + ' ' + v.description).toLowerCase().includes(q));
  if (status === 'published' || status === 'draft') vids = vids.filter((v) => v.status === status);
  const total = vids.length;
  const limit = Math.min(Math.max(1, +(sp.get('limit')) || 12), 100);
  const page = Math.max(1, +(sp.get('page')) || 1);
  json(res, 200, { videos: vids.slice((page - 1) * limit, page * limit).map(enrich), total, page, pages: Math.max(1, Math.ceil(total / limit)) });
}, true);

route('POST', '/api/admin/videos', (req, res, p, sp, b) => {
  const v = cleanVideo(b, {});
  if (!v.title) return json(res, 400, { error: 'Title is required.' });
  if (!v.videoUrl) return json(res, 400, { error: 'Video URL is required.' });
  if (!v.thumbnail) v.thumbnail = 'https://picsum.photos/seed/' + uid() + '/640/360';
  v.id = uid();
  v.slug = uniqueSlug(b.slug || v.title);
  v.createdAt = nowISO();
  v.updatedAt = nowISO();
  db.videos.unshift(v);
  saveDB();
  json(res, 200, { ok: true, video: enrich(v) });
}, true);

route('PUT', '/api/admin/videos/:id', (req, res, p, sp, b) => {
  const v = db.videos.find((x) => x.id === p.id);
  if (!v) return json(res, 404, { error: 'Video not found' });
  cleanVideo(b, v);
  if (!v.title) return json(res, 400, { error: 'Title is required.' });
  if (b.slug && b.slug !== v.slug) v.slug = uniqueSlug(b.slug, v.id);
  v.updatedAt = nowISO();
  saveDB();
  json(res, 200, { ok: true, video: enrich(v) });
}, true);

route('DELETE', '/api/admin/videos/:id', (req, res, p) => {
  const i = db.videos.findIndex((x) => x.id === p.id);
  if (i < 0) return json(res, 404, { error: 'Video not found' });
  db.videos.splice(i, 1);
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('POST', '/api/admin/categories', (req, res, p, sp, b) => {
  const name = String((b && b.name) || '').trim().slice(0, 60);
  if (!name) return json(res, 400, { error: 'Name is required.' });
  let slug = slugify(name); let i = 2;
  while (db.categories.some((c) => c.slug === slug)) { slug = slugify(name) + '-' + i; i++; }
  const c = { id: uid(), name, slug, icon: String((b && b.icon) || '🎬').slice(0, 8) };
  db.categories.push(c); saveDB();
  json(res, 200, { ok: true, category: c });
}, true);

route('PUT', '/api/admin/categories/:id', (req, res, p, sp, b) => {
  const c = db.categories.find((x) => x.id === p.id);
  if (!c) return json(res, 404, { error: 'Not found' });
  if (b.name) c.name = String(b.name).trim().slice(0, 60);
  if (b.icon !== undefined) c.icon = String(b.icon).slice(0, 8);
  saveDB();
  json(res, 200, { ok: true, category: c });
}, true);

route('DELETE', '/api/admin/categories/:id', (req, res, p) => {
  const i = db.categories.findIndex((x) => x.id === p.id);
  if (i < 0) return json(res, 404, { error: 'Not found' });
  db.categories.splice(i, 1);
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('GET', '/api/admin/settings', (req, res) => json(res, 200, { settings: publicSettings() }), true);

route('PUT', '/api/admin/settings', (req, res, p, sp, b) => {
  const ALLOW = ['siteName', 'logoText', 'logoAccent', 'tagline', 'contactEmail', 'headerNotice', 'playerNotice', 'footerCopyright', 'footerDisclaimer'];
  ALLOW.forEach((k) => { if (b[k] !== undefined) db.settings[k] = String(b[k]).slice(0, 2000); });
  if (b.videosPerPage !== undefined) db.settings.videosPerPage = Math.max(4, Math.min(100, +b.videosPerPage || 20));
  if (b.seo && typeof b.seo === 'object')
    ['title', 'description', 'keywords', 'ogImage'].forEach((k) => { if (b.seo[k] !== undefined) db.settings.seo[k] = String(b.seo[k]).slice(0, 500); });
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('GET', '/api/admin/ads', (req, res) => json(res, 200, db.ads), true);

route('PUT', '/api/admin/ads', (req, res, p, sp, b) => {
  if (b.adsensePublisherId !== undefined) db.ads.adsensePublisherId = String(b.adsensePublisherId).trim().slice(0, 60);
  if (b.headSnippet !== undefined) db.ads.headSnippet = String(b.headSnippet).slice(0, 30000);
  if (b.adsTxt !== undefined) db.ads.adsTxt = String(b.adsTxt).slice(0, 30000);
  if (b.zones && typeof b.zones === 'object') {
    for (const k of Object.keys(db.ads.zones)) {
      const z = b.zones[k];
      if (z) {
        db.ads.zones[k].enabled = !!z.enabled;
        if (z.code !== undefined) db.ads.zones[k].code = String(z.code).slice(0, 30000);
      }
    }
  }
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('GET', '/api/admin/pages', (req, res) => json(res, 200, { pages: db.pages }), true);

route('PUT', '/api/admin/pages/:slug', (req, res, p, sp, b) => {
  const pg = db.pages[p.slug];
  if (!pg) return json(res, 404, { error: 'Page not found' });
  if (b.title !== undefined) pg.title = String(b.title).slice(0, 200);
  if (b.content !== undefined) pg.content = String(b.content).slice(0, 80000);
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('GET', '/api/admin/messages', (req, res) => json(res, 200, { messages: db.messages }), true);

route('PUT', '/api/admin/messages/:id', (req, res, p, sp, b) => {
  const m = db.messages.find((x) => x.id === p.id);
  if (!m) return json(res, 404, { error: 'Not found' });
  m.read = !!(b && b.read);
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('DELETE', '/api/admin/messages/:id', (req, res, p) => {
  const i = db.messages.findIndex((x) => x.id === p.id);
  if (i < 0) return json(res, 404, { error: 'Not found' });
  db.messages.splice(i, 1);
  saveDB();
  json(res, 200, { ok: true });
}, true);

route('PUT', '/api/admin/password', (req, res, p, sp, b) => {
  const cur = String((b && b.current) || '');
  const next = String((b && b.next) || '');
  if (sha(cur) !== db.settings.adminPasswordHash) return json(res, 400, { error: 'Current password is incorrect.' });
  if (next.length < 6) return json(res, 400, { error: 'New password must be at least 6 characters.' });
  db.settings.adminPasswordHash = sha(next);
  saveDB();
  json(res, 200, { ok: true, message: 'Password updated successfully.' });
}, true);

/* --------------------------- static + SEO ---------------------------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif',
  '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2', '.mp4': 'video/mp4',
};
function serveFile(res, fp, noStore) {
  try {
    const ext = path.extname(fp).toLowerCase();
    const data = fs.readFileSync(fp);
    // HTML and all admin-panel assets are always fresh — a cached dashboard
    // shell must never appear where the login screen should be.
    const noCache = noStore || ext === '.html';
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': noCache ? 'no-store, no-cache, must-revalidate' : 'public, max-age=300',
      ...(noCache ? { 'Pragma': 'no-cache', 'Expires': '0' } : {}),
    });
    res.end(data);
  } catch (e) { text(res, 404, 'Not found'); }
}
function renderTokens(html, ctx) {
  ctx = ctx || {};
  const s = db.settings;
  const pub = (db.ads.adsensePublisherId || '').trim();
  const adsMeta = pub ? '<meta name="google-adsense-account" content="' + htmlEsc(pub) + '">' : '';
  return html
    .split('%%PAGE_TITLE%%').join(htmlEsc(ctx.title || s.seo.title || s.siteName))
    .split('%%SEO_DESC%%').join(htmlEsc(ctx.desc || s.seo.description || ''))
    .split('%%SEO_KEYWORDS%%').join(htmlEsc(s.seo.keywords || ''))
    .split('%%OG_IMAGE%%').join(htmlEsc(ctx.image || s.seo.ogImage || ''))
    .split('%%OG_URL%%').join(htmlEsc(ctx.url || ''))
    .split('%%CANONICAL%%').join(htmlEsc(ctx.url || ''))
    .split('%%ADSENSE_META%%').join(adsMeta)
    .split('%%HEAD_SNIPPET%%').join(db.ads.headSnippet || '');
}
function serveHtml(res, fp, ctx) {
  try {
    const html = fs.readFileSync(fp, 'utf8');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(renderTokens(html, ctx));
  } catch (e) { text(res, 404, 'Not found'); }
}
function sitemap(origin) {
  let u = '';
  const add = (loc, pr, last) => {
    u += '  <url>\n    <loc>' + xmlEsc(loc) + '</loc>\n';
    if (last) u += '    <lastmod>' + xmlEsc(last) + '</lastmod>\n';
    u += '    <changefreq>daily</changefreq>\n    <priority>' + pr + '</priority>\n  </url>\n';
  };
  add(origin + '/', '1.0', nowISO().slice(0, 10));
  ['about', 'contact', 'privacy-policy', 'terms', 'dmca', 'disclaimer'].forEach((p) => add(origin + '/page?p=' + p, '0.6'));
  db.videos.filter((v) => v.status === 'published').forEach((v) =>
    add(origin + '/watch?v=' + encodeURIComponent(v.slug), '0.8', (v.updatedAt || '').slice(0, 10)));
  return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + u + '</urlset>';
}

function serveAdminApp(res) {
  // The admin panel is served as ONE self-contained document: CSS and JS are
  // inlined server-side on every request, and the document is no-store.
  // => the browser can never combine a stale cached script with a new page,
  //    which is what previously blocked the dashboard after login.
  try {
    let html = fs.readFileSync(path.join(ADMIN_DIR, 'index.html'), 'utf8')
      .split('%%V%%').join(String(Date.now()));
    try {
      const css = fs.readFileSync(path.join(ADMIN_DIR, 'admin.css'), 'utf8');
      html = html.replace(/<link rel="stylesheet" href="\/admin\/admin\.css\?v=[^"]*"\s*\/?>/,
        () => '<style>\n' + css + '\n</style>');
    } catch (e) { /* keep external link fallback */ }
    try {
      const js = fs.readFileSync(path.join(ADMIN_DIR, 'admin.js'), 'utf8')
        .replace(/<\/script/gi, '<\\/script');
      html = html.replace(/<script src="\/admin\/admin\.js\?v=[^"]*"><\/script>/,
        () => '<script>\n' + js + '\n</script>');
    } catch (e) { /* keep external script fallback */ }
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
    });
    res.end(html);
  } catch (e) { text(res, 500, 'Admin panel unavailable'); }
}

function servePublic(req, res, pathname, sp, origin, rawUrl) {
  if (pathname === '/admin' || pathname === '/admin/' || pathname === '/panel' || pathname === '/panel/')
    return serveAdminApp(res);
  if (pathname.startsWith('/admin/')) {
    const f = path.normalize(path.join(ADMIN_DIR, pathname.slice(7)));
    if (!f.startsWith(ADMIN_DIR)) return text(res, 403, 'Forbidden');
    if (fs.existsSync(f) && fs.statSync(f).isFile()) return serveFile(res, f, true);
    return text(res, 404, 'Not found');
  }
  const htmlMap = { '/': 'index.html', '/index.html': 'index.html', '/watch': 'watch.html', '/watch.html': 'watch.html', '/page': 'page.html', '/page.html': 'page.html' };
  if (htmlMap[pathname]) {
    const ctx = { url: origin + rawUrl };
    if (htmlMap[pathname] === 'index.html') {
      const q = sp.get('q'), cat = sp.get('cat');
      if (q) { ctx.title = 'Search: ' + q + ' — ' + db.settings.siteName; ctx.desc = 'Search results for ' + q + ' on ' + db.settings.siteName; }
      else if (cat) {
        const c = db.categories.find((c) => c.slug === cat);
        if (c) { ctx.title = c.name + ' Videos — ' + db.settings.siteName; ctx.desc = 'Watch the best ' + c.name + ' videos on ' + db.settings.siteName; }
      }
    }
    if (htmlMap[pathname] === 'watch.html') {
      const s = sp.get('v');
      const v = s && db.videos.find((x) => (x.slug === s || x.id === s) && x.status === 'published');
      if (v) {
        ctx.title = (v.seoTitle || v.title) + ' — ' + db.settings.siteName;
        ctx.desc = v.seoDescription || String(v.description || '').slice(0, 160);
        ctx.image = v.thumbnail;
      }
    }
    if (htmlMap[pathname] === 'page.html') {
      const pg = db.pages[sp.get('p') || 'about'];
      if (pg) {
        ctx.title = pg.title + ' — ' + db.settings.siteName;
        ctx.desc = String(pg.content || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 160);
      }
    }
    return serveHtml(res, path.join(PUBLIC_DIR, htmlMap[pathname]), ctx);
  }
  const f = path.normalize(path.join(PUBLIC_DIR, pathname));
  if (!f.startsWith(PUBLIC_DIR)) return text(res, 403, 'Forbidden');
  if (fs.existsSync(f) && fs.statSync(f).isFile()) return serveFile(res, f);
  text(res, 404, '404 — Not Found');
}

/* ------------------------------ server ------------------------------- */
async function handleApi(req, res, pathname, sp) {
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.rx.exec(pathname);
    if (!m) continue;
    if (r.admin && !authToken(req)) return json(res, 401, { error: 'Unauthorized. Please log in again.' });
    const params = {};
    r.names.forEach((n, i) => (params[n] = decodeURIComponent(m[i + 1])));
    let body = null;
    if (req.method === 'POST' || req.method === 'PUT') {
      const raw = await readBody(req);
      try { body = raw ? JSON.parse(raw) : {}; }
      catch (e) { return json(res, 400, { error: 'Invalid JSON body' }); }
    }
    return r.handler(req, res, params, sp, body);
  }
  json(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  try {
    const proto = req.headers['x-forwarded-proto'] || 'http';
    const host = req.headers.host || 'localhost:' + PORT;
    const origin = proto + '://' + host;
    const u = new URL(req.url, origin);
    const pathname = decodeURIComponent(u.pathname);
    if (pathname.startsWith('/api/')) return await handleApi(req, res, pathname, u.searchParams);
    if (pathname === '/robots.txt')
      return text(res, 200, 'User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /panel\n\nSitemap: ' + origin + '/sitemap.xml\n');
    if (pathname === '/sitemap.xml') return text(res, 200, sitemap(origin), 'application/xml; charset=utf-8');
    if (pathname === '/ads.txt')
      return text(res, 200, db.ads.adsTxt || '# ads.txt — configure this in the TRENDPOPTV Admin Panel → Ads section\n');
    return servePublic(req, res, pathname, u.searchParams, origin, req.url);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) text(res, 500, 'Internal Server Error');
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n  ▶  TRENDPOPTV is running!');
  console.log('  ─────────────────────────────────────────');
  console.log('  Website : http://localhost:' + PORT + '/');
  console.log('  Admin   : http://localhost:' + PORT + '/admin  (sign in with your admin password)');
  console.log('  ─────────────────────────────────────────\n');
});
