# 🎬 TRENDPOPTV — Video Streaming Platform + Admin Panel

A complete, professional video streaming website (dark premium theme) with a **full-featured admin panel** to manage everything: videos, images, ads, categories, pages, texts and SEO.

**Zero dependencies** — pure Node.js. No npm install required.

---

## 🚀 Quick Start

```bash
cd trendpoptv
node server.js          # or: npm start
```

| URL | What |
|---|---|
| `http://localhost:3000/` | Public website |
| `http://localhost:3000/panel` | **Admin Panel** (password protected) |
| `http://localhost:3000/admin` | Admin Panel (same app, alternate URL) |
| `http://localhost:3000/sitemap.xml` | Auto-generated sitemap |
| `http://localhost:3000/robots.txt` | Robots file |
| `http://localhost:3000/ads.txt` | ads.txt (editable in admin) |

## 🔐 Admin Login & Security

- The **initial** admin password is `admin123` (documented here only — it is never shown on the website).
- Change it immediately after first login: **Admin → Settings → Change Admin Password**.
- **The dashboard is never shown before authentication.** `/panel` first shows a session-check loader, then either the login screen (no/expired session) or the panel (verified session) — never both.
- The admin app is served as **one self-contained, no-store document** (CSS+JS inlined server-side), so a stale cached file can never break the login flow.
- Sessions last until you log out or close the browser. Tick **"Keep me signed in"** on the login form to stay signed in for 7 days on that device.
- The login page has **brute-force protection**: 8 failed attempts from one IP locks that IP for 10 minutes.
- Passwords are stored as SHA-256 hashes (never plain text), sessions use random 7-day tokens, and password checks are timing-safe.

**Forgot your password?** Generate a new hash and paste it into `data/db.json` → `settings.adminPasswordHash`, then restart:

```bash
node -e "console.log(require('crypto').createHash('sha256').update('yourNewPassword').digest('hex'))"
```

---

## ✨ Features

### Public Website
- **Home page** — All / 🔥 Trending / ★ Latest / ♛ Most Viewed tabs, video grid with VIDEO + 1080p badges, view counts, dates, pagination
- **Watch page** — custom video player (play overlay, seek bar, volume, speed menu, loop, fullscreen, keyboard shortcuts), release date, live view counter, ad notice bar, description, picture section, related videos
- **Search** — full-screen live search overlay + searchable home page (`/?q=`)
- **Categories** — slide-in drawer with category filters (`/?cat=`)
- **Both MP4/HLS direct videos and YouTube embeds** supported per-video
- Fully responsive (4 → 3 → 2 → 1 column), dark purple-gradient theme

### Admin Panel (`/admin`)
- **📊 Dashboard** — stats, recent videos, AdSense approval checklist
- **🎬 Videos** — add / edit / duplicate / delete / drafts / search / pagination
  - per-video: title, description, category, tags, video URL (MP4 or YouTube), thumbnail (live preview), duration, quality badge, publish date, views counter, 🔥 trending & ⭐ featured flags, **multiple images**, custom SEO title & description
- **🗂️ Categories** — create / edit / delete with emoji icons
- **📢 Ads & AdSense** — publisher ID, verification/Auto-Ads head snippet, ads.txt, and **5 toggleable ad zones** (header, home feed, below player, after related, above footer)
- **📄 Pages** — edit About, Contact, Privacy Policy, Terms, DMCA, Disclaimer (ready-written, AdSense-friendly)
- **✉️ Messages** — contact-form inbox with read/unread + reply
- **⚙️ Settings** — logo, site name, tagline, notices, footer texts, videos-per-page, SEO meta, password change

### AdSense Approval Ready
- ✅ Privacy Policy (with Google AdSense / DART cookie section), Terms, DMCA, About, Contact, Disclaimer pages pre-written
- ✅ `sitemap.xml`, `robots.txt`, `ads.txt` auto-served
- ✅ SEO meta + Open Graph tags injected server-side on every page (video pages get per-video meta)
- ✅ `google-adsense-account` meta auto-added when you set your Publisher ID
- ✅ Contact form, content-rich pages, clean navigation

### Getting AdSense approval (checklist)
1. Deploy the site on a real domain (see below)
2. Admin → **Ads & AdSense**: paste verification snippet + Publisher ID + ads.txt line
3. Publish 15–20+ videos with unique titles/descriptions
4. Add your own original text to About/pages (edit in **Pages** tab)
5. Submit in AdSense console → wait for review
6. After approval: enable ad zones + paste ad-unit codes

---

## 📁 Structure

```
trendpoptv/
├── server.js            # entire backend (no dependencies!)
├── package.json
├── data/db.json         # auto-created database (videos, ads, pages, settings, messages)
├── public/              # public website
│   ├── index.html       # home
│   ├── watch.html       # video player page
│   ├── page.html        # static pages (about/privacy/…)
│   ├── css/style.css
│   └── js/app.js, home.js, watch.js, page.js
└── admin/               # admin panel (single-page app)
    ├── index.html
    ├── admin.css
    └── admin.js
```

## 💾 Data & Backups
Everything is stored in **`data/db.json`** — back it up by copying that one file.
Delete it and restart to re-seed demo content.

## 🌐 Deployment
Works on any Node.js host (Render, Railway, VPS, Replit…):

```bash
PORT=80 node server.js        # choose port via env var
```

Put it behind your domain + HTTPS (AdSense requires a real domain), and you're done.

## ⚠️ Notes
- Demo videos use Google's public sample MP4s and picsum.photos images — replace with your own content via the admin panel.
- The site does not host video files; you stream from your own URLs (YouTube, CDN, direct MP4/HLS links), matching the DMCA/disclaimer pages.
