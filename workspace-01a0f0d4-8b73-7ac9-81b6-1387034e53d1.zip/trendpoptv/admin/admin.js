/* ============================================================
   TRENDPOPTV — Admin Panel application
   Views: Dashboard, Videos, Categories, Ads, Pages, Messages, Settings
   ============================================================ */
'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtN = (n) => {
  n = +n || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
  return String(n);
};
const fmtD = (d) => {
  const t = new Date(d);
  return isNaN(t) ? String(d || '') : t.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

const A = {
  token: sessionStorage.getItem('tp_admin') || localStorage.getItem('tp_admin') || '',
  route: (location.hash || '#/dashboard').slice(2) || 'dashboard',
  vf: { q: '', status: '', page: 1 },
  cats: [],
  pages: null,
  curPage: 'about',
};

/* ============================================================
   SCREEN CONTROL — exactly ONE of { boot, login, app } visible
   at any moment. Uses both `hidden` attr AND inline display so
   no cached/stale CSS can ever reveal the dashboard early.
   ============================================================ */
function showScreen(name) {
  const views = { boot: '#bootView', login: '#loginView', app: '#appView' };
  for (const [k, sel] of Object.entries(views)) {
    const el = $(sel);
    if (!el) continue;
    if (k === name) {
      el.hidden = false;
      el.style.display = k === 'app' ? 'grid' : 'flex';
    } else {
      el.hidden = true;
      el.style.display = 'none';
    }
  }
}

function enterApp() {
  showScreen('app');
  renderRoute();
  refreshBadges();
}

function saveToken(token, remember) {
  A.token = token;
  if (remember) {
    localStorage.setItem('tp_admin', token);
    localStorage.setItem('tp_remember', '1');
    sessionStorage.removeItem('tp_admin');
  } else {
    sessionStorage.setItem('tp_admin', token);
    localStorage.removeItem('tp_admin');
    localStorage.removeItem('tp_remember');
  }
}

function clearToken() {
  A.token = '';
  sessionStorage.removeItem('tp_admin');
  localStorage.removeItem('tp_admin');
  localStorage.removeItem('tp_remember');
}

/* ------------------------------ API ------------------------------ */
async function api(path, o = {}) {
  o.headers = Object.assign({ 'Content-Type': 'application/json' }, o.headers || {});
  if (A.token) o.headers.Authorization = 'Bearer ' + A.token;
  const r = await fetch(path, o);
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) { logout(false); throw new Error(d.error || 'Session expired'); }
  if (!r.ok) throw new Error(d.error || 'Request failed (' + r.status + ')');
  return d;
}

/* ------------------------------ UI helpers ------------------------------ */
function toast(msg, type) {
  const root = $('#toast');
  const t = document.createElement('div');
  t.className = 'toast ' + (type || '');
  t.textContent = msg;
  root.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, 3400);
}

function openModal(title, bodyHTML, opts) {
  opts = opts || {};
  const root = $('#modalRoot');
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal ${opts.small ? 'sm' : ''}">
    <div class="m-head"><h3>${esc(title)}</h3><button type="button" data-close>✕</button></div>
    <div class="m-body">${bodyHTML}</div>
  </div>`;
  root.appendChild(bg);
  const close = () => bg.remove();
  bg.addEventListener('click', (e) => {
    if (e.target === bg || e.target.closest('[data-close]')) close();
  });
  return { bg, close };
}

function confirmBox(title, body, okText) {
  return new Promise((resolve) => {
    const { bg, close } = openModal(title, `
      <p style="font-size:14px;color:#cfcfe6;line-height:1.7">${body}</p>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px">
        <button class="btn ghost" data-close>Cancel</button>
        <button class="btn danger" id="cfOk">${esc(okText || 'Delete')}</button>
      </div>`, { small: true });
    bg.querySelector('#cfOk').addEventListener('click', () => { close(); resolve(true); });
    bg.addEventListener('click', (e) => { if (e.target === bg || e.target.closest('[data-close]')) resolve(false); });
  });
}

/* ------------------------------ auth ------------------------------ */
function logout(callApi = true) {
  if (callApi && A.token) api('/api/admin/logout', { method: 'POST', body: '{}' }).catch(() => {});
  clearToken();
  showScreen('login');
}

const loginBtn = $('#loginBtn');
const loginPass = $('#loginPass');

/* show / hide password */
$('#togglePass').addEventListener('click', () => {
  const show = loginPass.type === 'password';
  loginPass.type = show ? 'text' : 'password';
  $('#togglePass').textContent = show ? '🙈' : '👁️';
  $('#togglePass').setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  loginPass.focus();
});

/* clear the error as soon as the user starts typing again */
loginPass.addEventListener('input', () => {
  $('#loginErr').textContent = '';
  $('#loginForm').classList.remove('shake');
});

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errBox = $('#loginErr');
  errBox.textContent = '';
  loginBtn.disabled = true;
  loginBtn.innerHTML = '⏳ Signing in…';
  try {
    const d = await api('/api/admin/login', { method: 'POST', body: JSON.stringify({ password: loginPass.value }) });
    if (!d || !d.token) throw new Error('Login failed — unexpected server response.');
    const keepEl = $('#keepMe');
    saveToken(d.token, keepEl ? !!keepEl.checked : false);
    loginPass.value = '';
    enterApp();
    toast('Welcome back! 👋', 'ok');
  } catch (err) {
    errBox.textContent = err.message;
    const card = $('#loginForm');
    card.classList.remove('shake');
    void card.offsetWidth; /* restart animation */
    card.classList.add('shake');
    loginPass.select();
  } finally {
    loginBtn.disabled = false;
    loginBtn.innerHTML = '🔓 Sign In';
  }
});
$('#logoutBtn').addEventListener('click', () => logout(true));
$('#sbToggle').addEventListener('click', () => $('#appView').classList.toggle('sb-open'));

/* ------------------------------ router ------------------------------ */
const TITLES = {
  dashboard: '📊 Dashboard', videos: '🎬 Videos', categories: '🗂️ Categories',
  ads: '📢 Ads & AdSense', pages: '📄 Pages Editor', messages: '✉️ Messages', settings: '⚙️ Settings',
};
window.addEventListener('hashchange', () => {
  A.route = (location.hash || '#/dashboard').slice(2) || 'dashboard';
  renderRoute();
});
$('#sbNav').addEventListener('click', (e) => {
  const b = e.target.closest('[data-r]');
  if (!b) return;
  location.hash = '#/' + b.dataset.r;
  $('#appView').classList.remove('sb-open');
});

async function renderRoute() {
  $$('#sbNav [data-r]').forEach((b) => b.classList.toggle('on', b.dataset.r === A.route));
  $('#pageTitle').textContent = TITLES[A.route] || 'Dashboard';
  const view = $('#view');
  view.innerHTML = '<div class="panel muted">Loading…</div>';
  try {
    if (A.route === 'videos') await vVideos(view);
    else if (A.route === 'categories') await vCategories(view);
    else if (A.route === 'ads') await vAds(view);
    else if (A.route === 'pages') await vPages(view);
    else if (A.route === 'messages') await vMessages(view);
    else if (A.route === 'settings') await vSettings(view);
    else await vDashboard(view);
  } catch (err) {
    view.innerHTML = `<div class="panel"><div class="empty-rows">⚠️ ${esc(err.message)}</div></div>`;
  }
}

async function refreshBadges() {
  try {
    const s = await api('/api/admin/stats');
    const nv = $('#navVideos'), nm = $('#navMsgs');
    nv.textContent = s.videos.total; nv.hidden = false;
    if (s.messages.unread > 0) { nm.textContent = s.messages.unread; nm.hidden = false; } else nm.hidden = true;
  } catch (e) { /* ignore */ }
}

/* ============================== DASHBOARD ============================== */
async function vDashboard(view) {
  const s = await api('/api/admin/stats');
  view.innerHTML = `
  <div class="stats">
    <div class="stat"><span class="ic">🎬</span><div class="num">${s.videos.total}</div><div class="lbl">Total Videos (${s.videos.published} published)</div></div>
    <div class="stat"><span class="ic">👁</span><div class="num">${fmtN(s.views)}</div><div class="lbl">Total Views</div></div>
    <div class="stat"><span class="ic">🗂️</span><div class="num">${s.categories}</div><div class="lbl">Categories</div></div>
    <div class="stat"><span class="ic">✉️</span><div class="num">${s.messages.unread}</div><div class="lbl">Unread Messages</div></div>
  </div>

  <div class="panel">
    <h2>🕒 Recently Added Videos</h2>
    <p class="muted">Latest uploads across the site</p>
    <div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th>Video</th><th>Views</th><th>Date</th><th>Status</th><th></th>
    </tr></thead><tbody>
    ${s.recent.map((v) => `<tr>
      <td><div class="cell-vid"><img src="${esc(v.thumbnail)}" alt=""><div><div class="t">${esc(v.title)}</div><div class="s">/${esc(v.slug)}</div></div></div></td>
      <td>${fmtN(v.views)}</td>
      <td>${fmtD(v.date)}</td>
      <td><span class="pill-st ${v.status === 'draft' ? 'draft' : 'pub'}">${v.status === 'draft' ? 'Draft' : 'Published'}</span></td>
      <td><a class="btn sm" href="/watch?v=${encodeURIComponent(v.slug)}" target="_blank">View ↗</a></td>
    </tr>`).join('') || '<tr><td colspan="5" class="empty-rows">No videos yet — add your first one!</td></tr>'}
    </tbody></table></div>
    <div class="q-actions">
      <button class="btn primary" id="qAdd">＋ Add New Video</button>
      <a class="btn" href="/" target="_blank">↗ Open Website</a>
    </div>
  </div>

  <div class="panel">
    <h2>✅ AdSense Approval Checklist</h2>
    <p class="muted">Follow these steps to get your site ready for Google AdSense review</p>
    <ul class="check-list">
      <li><span class="dot">✅</span><span><b>Policy pages live</b> — About, Contact, Privacy Policy, Terms, DMCA & Disclaimer are already created (editable in <b>Pages</b>).</span></li>
      <li><span class="dot">✅</span><span><b>SEO ready</b> — meta tags, sitemap (<span class="kbd">/sitemap.xml</span>), robots.txt and clean URLs are generated automatically.</span></li>
      <li><span class="dot">1️⃣</span><span>Go to <b>Ads &amp; AdSense</b> → paste your AdSense verification snippet &amp; Publisher ID.</span></li>
      <li><span class="dot">2️⃣</span><span>Add your <b>ads.txt</b> line (served automatically at <span class="kbd">/ads.txt</span>).</span></li>
      <li><span class="dot">3️⃣</span><span>Publish 15–20+ videos with unique titles &amp; descriptions (AdSense loves content-rich sites).</span></li>
      <li><span class="dot">4️⃣</span><span>Submit the site in your AdSense dashboard and wait for review (usually 1–14 days).</span></li>
      <li><span class="dot">5️⃣</span><span>After approval, enable ad zones and paste your ad-unit codes — they go live instantly.</span></li>
    </ul>
  </div>`;
  $('#qAdd').addEventListener('click', () => { location.hash = '#/videos'; setTimeout(() => { const b = $('#addVid'); if (b) b.click(); }, 350); });
}

/* ============================== VIDEOS ============================== */
async function vVideos(view) {
  const vf = A.vf;
  const d = await api(`/api/admin/videos?q=${encodeURIComponent(vf.q)}&status=${vf.status}&page=${vf.page}&limit=12`);
  view.innerHTML = `
  <div class="toolbar">
    <input type="text" id="vq" placeholder="🔍 Search title or description…" value="${esc(vf.q)}">
    <select id="vstatus">
      <option value="" ${vf.status === '' ? 'selected' : ''}>All statuses</option>
      <option value="published" ${vf.status === 'published' ? 'selected' : ''}>Published</option>
      <option value="draft" ${vf.status === 'draft' ? 'draft' : ''}>Draft</option>
    </select>
    <span class="count">${d.total} video${d.total === 1 ? '' : 's'}</span>
    <button class="btn primary" id="addVid">＋ Add Video</button>
  </div>
  <div class="panel" style="padding:8px 0 0">
    <div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th style="padding-left:20px">Video</th><th>Category</th><th>Quality</th><th>Views</th><th>Date</th><th>Status</th><th></th>
    </tr></thead><tbody id="vrows">
    ${d.videos.map((v) => `<tr>
      <td style="padding-left:20px"><div class="cell-vid"><img src="${esc(v.thumbnail)}" alt=""><div>
        <div class="t">${v.trending ? '<span class="tr-flag">🔥</span> ' : ''}${esc(v.title)}</div>
        <div class="s">/${esc(v.slug)}</div></div></div></td>
      <td>${esc(v.categoryIcon || '')} ${esc(v.categoryName || v.category)}</td>
      <td>${esc(v.quality || '1080p')}</td>
      <td>${fmtN(v.views)}</td>
      <td>${fmtD(v.date)}</td>
      <td><span class="pill-st ${v.status === 'draft' ? 'draft' : 'pub'}">${v.status === 'draft' ? 'Draft' : 'Published'}</span></td>
      <td><div class="row-acts">
        <button class="btn sm" data-edit="${v.id}">✏️ Edit</button>
        <button class="btn sm" data-dup="${v.id}" title="Duplicate">⧉</button>
        <button class="btn sm danger" data-del="${v.id}">🗑</button>
      </div></td>
    </tr>`).join('') || '<tr><td colspan="7" class="empty-rows">No videos found. Click “＋ Add Video” to create one.</td></tr>'}
    </tbody></table></div>
    <div class="apager" id="vpages"></div>
  </div>`;

  // toolbar
  let t;
  $('#vq').addEventListener('input', (e) => {
    clearTimeout(t);
    t = setTimeout(() => { A.vf.q = e.target.value.trim(); A.vf.page = 1; vVideos(view); }, 350);
  });
  $('#vstatus').addEventListener('change', (e) => { A.vf.status = e.target.value; A.vf.page = 1; vVideos(view); });
  $('#addVid').addEventListener('click', () => videoEditor(null, view));

  // pager
  const pg = $('#vpages');
  if (d.pages > 1) {
    let h = `<button data-p="${d.page - 1}" ${d.page === 1 ? 'disabled' : ''}>‹</button>`;
    for (let i = 1; i <= d.pages; i++) h += `<button data-p="${i}" class="${i === d.page ? 'on' : ''}">${i}</button>`;
    h += `<button data-p="${d.page + 1}" ${d.page === d.pages ? 'disabled' : ''}>›</button>`;
    pg.innerHTML = h;
    pg.addEventListener('click', (e) => {
      const b = e.target.closest('[data-p]');
      if (!b || b.disabled) return;
      A.vf.page = +b.dataset.p;
      vVideos(view);
    });
  }

  // row actions
  $('#vrows').addEventListener('click', async (e) => {
    const ed = e.target.closest('[data-edit]');
    const du = e.target.closest('[data-dup]');
    const del = e.target.closest('[data-del]');
    if (ed) {
      const v = d.videos.find((x) => x.id === ed.dataset.edit);
      videoEditor(v, view);
    } else if (du) {
      const v = d.videos.find((x) => x.id === du.dataset.dup);
      try {
        const copy = Object.assign({}, v, { title: v.title + ' (Copy)', views: 0 });
        delete copy.id; delete copy.slug; delete copy.createdAt; delete copy.updatedAt; delete copy.categoryName; delete copy.categoryIcon;
        await api('/api/admin/videos', { method: 'POST', body: JSON.stringify(copy) });
        toast('Video duplicated ✅', 'ok');
        vVideos(view); refreshBadges();
      } catch (err) { toast(err.message, 'err'); }
    } else if (del) {
      const v = d.videos.find((x) => x.id === del.dataset.del);
      const ok = await confirmBox('Delete video?', `This will permanently delete <b>${esc(v.title)}</b>. This action cannot be undone.`, 'Delete Video');
      if (!ok) return;
      try {
        await api('/api/admin/videos/' + v.id, { method: 'DELETE' });
        toast('Video deleted', 'ok');
        vVideos(view); refreshBadges();
      } catch (err) { toast(err.message, 'err'); }
    }
  });
}

async function videoEditor(v, view) {
  const isNew = !v;
  v = v || { status: 'published', videoType: 'mp4', quality: '1080p', date: new Date().toISOString().slice(0, 10), views: 0, images: [], tags: [], trending: false, featured: false };
  if (!A.cats.length) A.cats = (await api('/api/bootstrap').catch(() => ({ categories: [] }))).categories || [];

  const { bg, close } = openModal(isNew ? '➕ Add New Video' : '✏️ Edit Video', `
  <form id="vf" class="form">
    <div class="fg2">
      <div class="fld span2"><label>TITLE *</label>
        <input id="f_title" required maxlength="200" value="${esc(v.title || '')}" placeholder="e.g. Must Watch 💥"></div>
      <div class="fld"><label>CATEGORY</label>
        <select id="f_cat">${A.cats.map((c) => `<option value="${esc(c.slug)}" ${c.slug === v.category ? 'selected' : ''}>${esc(c.icon || '')} ${esc(c.name)}</option>`).join('')}</select></div>
      <div class="fld"><label>STATUS</label>
        <select id="f_status">
          <option value="published" ${v.status !== 'draft' ? 'selected' : ''}>Published</option>
          <option value="draft" ${v.status === 'draft' ? 'selected' : ''}>Draft (hidden)</option>
        </select></div>
      <div class="fld span2"><label>DESCRIPTION</label>
        <textarea id="f_desc" rows="3" placeholder="Shown on the watch page & used for SEO meta description">${esc(v.description || '')}</textarea></div>
      <div class="fld"><label>VIDEO SOURCE</label>
        <select id="f_type">
          <option value="mp4" ${v.videoType !== 'youtube' ? 'selected' : ''}>Direct video (MP4 / HLS)</option>
          <option value="youtube" ${v.videoType === 'youtube' ? 'selected' : ''}>YouTube embed</option>
        </select></div>
      <div class="fld"><label>VIDEO URL *</label>
        <input id="f_url" required value="${esc(v.videoUrl || '')}" placeholder="https://…/video.mp4  or  YouTube link"></div>
      <div class="fld span2"><label>THUMBNAIL URL</label>
        <div class="thumb-in"><input id="f_thumb" value="${esc(v.thumbnail || '')}" placeholder="https://…/thumbnail.jpg"><img id="f_thumbPv" src="${esc(v.thumbnail || '')}" alt=""></div></div>
      <div class="fld"><label>DURATION LABEL</label>
        <input id="f_dur" value="${esc(v.duration || '')}" placeholder="4:41"></div>
      <div class="fld"><label>QUALITY BADGE</label>
        <select id="f_q">${['1080p', '720p', '4K', 'HD'].map((q) => `<option ${v.quality === q ? 'selected' : ''}>${q}</option>`).join('')}</select></div>
      <div class="fld"><label>PUBLISH DATE</label>
        <input type="date" id="f_date" value="${esc((v.date || '').slice(0, 10))}"></div>
      <div class="fld"><label>VIEWS COUNT</label>
        <input type="number" min="0" id="f_views" value="${+v.views || 0}"></div>
      <div class="fld span2"><label>TAGS (comma separated)</label>
        <input id="f_tags" value="${esc((v.tags || []).join(', '))}" placeholder="trending, viral, music"></div>
      <div class="fld span2 checks">
        <label class="chk"><input type="checkbox" id="f_tr" ${v.trending ? 'checked' : ''}> 🔥 Trending tab boost</label>
        <label class="chk"><input type="checkbox" id="f_ft" ${v.featured ? 'checked' : ''}> ⭐ Featured</label>
      </div>
      <div class="fld span2"><label>IMAGES / PICTURES (watch page “Picture” section)</label>
        <div id="imgList"></div>
        <button type="button" class="btn ghost sm" id="addImg">＋ Add image URL</button>
      </div>
      <div class="fld span2"><label>SEO TITLE <span style="color:var(--muted2)">(optional)</span></label>
        <input id="f_seot" maxlength="200" value="${esc(v.seoTitle || '')}" placeholder="Defaults to video title"></div>
      <div class="fld span2"><label>SEO DESCRIPTION <span style="color:var(--muted2)">(optional)</span></label>
        <textarea id="f_seod" rows="2" maxlength="300" placeholder="Custom meta description for search engines">${esc(v.seoDescription || '')}</textarea></div>
    </div>
    <div class="m-foot">
      <button type="button" class="btn ghost" data-close>Cancel</button>
      <button class="btn primary" id="f_save">${isNew ? '＋ Publish Video' : '💾 Save Changes'}</button>
    </div>
  </form>`);

  // thumbnail live preview
  const ThumbPv = bg.querySelector('#f_thumbPv');
  bg.querySelector('#f_thumb').addEventListener('input', (e) => (ThumbPv.src = e.target.value.trim()));
  ThumbPv.onerror = () => (ThumbPv.style.opacity = 0.2);
  ThumbPv.onload = () => (ThumbPv.style.opacity = 1);

  // images list
  const imgList = bg.querySelector('#imgList');
  function imgRow(url) {
    const row = document.createElement('div');
    row.className = 'img-row';
    row.innerHTML = `<input placeholder="https://…/image.jpg" value="${esc(url || '')}"><img alt=""><button type="button" title="Remove">✕</button>`;
    const img = row.querySelector('img');
    const set = () => { img.src = row.querySelector('input').value.trim(); };
    set();
    row.querySelector('input').addEventListener('input', set);
    row.querySelector('button').addEventListener('click', () => row.remove());
    imgList.appendChild(row);
  }
  (v.images || []).forEach(imgRow);
  bg.querySelector('#addImg').addEventListener('click', () => imgRow(''));

  // save
  bg.querySelector('#vf').addEventListener('submit', async (e) => {
    e.preventDefault();
    const saveBtn = bg.querySelector('#f_save');
    saveBtn.disabled = true;
    const payload = {
      title: bg.querySelector('#f_title').value.trim(),
      description: bg.querySelector('#f_desc').value,
      category: bg.querySelector('#f_cat').value,
      status: bg.querySelector('#f_status').value,
      videoType: bg.querySelector('#f_type').value,
      videoUrl: bg.querySelector('#f_url').value.trim(),
      thumbnail: bg.querySelector('#f_thumb').value.trim(),
      duration: bg.querySelector('#f_dur').value.trim(),
      quality: bg.querySelector('#f_q').value,
      date: bg.querySelector('#f_date').value,
      views: +bg.querySelector('#f_views').value || 0,
      tags: bg.querySelector('#f_tags').value.split(',').map((s) => s.trim()).filter(Boolean),
      trending: bg.querySelector('#f_tr').checked,
      featured: bg.querySelector('#f_ft').checked,
      images: $$('.img-row input', imgList).map((i) => i.value.trim()).filter(Boolean),
      seoTitle: bg.querySelector('#f_seot').value.trim(),
      seoDescription: bg.querySelector('#f_seod').value.trim(),
    };
    try {
      if (isNew) await api('/api/admin/videos', { method: 'POST', body: JSON.stringify(payload) });
      else await api('/api/admin/videos/' + v.id, { method: 'PUT', body: JSON.stringify(payload) });
      toast(isNew ? 'Video published! 🎉' : 'Video saved ✅', 'ok');
      close();
      vVideos(view);
      refreshBadges();
    } catch (err) {
      toast(err.message, 'err');
      saveBtn.disabled = false;
    }
  });
}

/* ============================== CATEGORIES ============================== */
async function vCategories(view) {
  const boot = await api('/api/bootstrap');
  A.cats = boot.categories || [];
  view.innerHTML = `
  <div class="toolbar">
    <span class="count">${A.cats.length} categor${A.cats.length === 1 ? 'y' : 'ies'}</span>
    <span class="spacer"></span>
    <button class="btn primary" id="addCat">＋ Add Category</button>
  </div>
  <div class="panel" style="padding:8px 0 0">
    <div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th style="padding-left:20px">Icon</th><th>Name</th><th>Slug</th><th></th>
    </tr></thead><tbody id="crow">
    ${A.cats.map((c) => `<tr>
      <td style="padding-left:20px;font-size:20px">${esc(c.icon || '🎬')}</td>
      <td><b>${esc(c.name)}</b></td>
      <td class="muted">/${esc(c.slug)}</td>
      <td><div class="row-acts">
        <button class="btn sm" data-edit="${c.id}">✏️ Edit</button>
        <button class="btn sm danger" data-del="${c.id}">🗑</button>
      </div></td>
    </tr>`).join('') || '<tr><td colspan="4" class="empty-rows">No categories yet.</td></tr>'}
    </tbody></table></div>
  </div>`;

  $('#addCat').addEventListener('click', () => catEditor(null, view));
  $('#crow').addEventListener('click', async (e) => {
    const ed = e.target.closest('[data-edit]');
    const del = e.target.closest('[data-del]');
    if (ed) catEditor(A.cats.find((c) => c.id === ed.dataset.edit), view);
    if (del) {
      const c = A.cats.find((x) => x.id === del.dataset.del);
      const ok = await confirmBox('Delete category?', `Delete <b>${esc(c.name)}</b>? Videos in it will keep their label but the category filter will disappear.`, 'Delete');
      if (!ok) return;
      try {
        await api('/api/admin/categories/' + c.id, { method: 'DELETE' });
        toast('Category deleted', 'ok');
        vCategories(view);
      } catch (err) { toast(err.message, 'err'); }
    }
  });
}

function catEditor(c, view) {
  const isNew = !c;
  const { bg, close } = openModal(isNew ? '＋ Add Category' : '✏️ Edit Category', `
    <div class="fld" style="margin-bottom:12px"><label>ICON (emoji)</label>
      <input id="c_icon" value="${esc(c ? c.icon : '🎬')}" maxlength="8"></div>
    <div class="fld"><label>NAME *</label>
      <input id="c_name" value="${esc(c ? c.name : '')}" maxlength="60" placeholder="e.g. Comedy"></div>
    <div class="m-foot" style="margin:18px -22px -22px">
      <button type="button" class="btn ghost" data-close>Cancel</button>
      <button class="btn primary" id="c_save">${isNew ? '＋ Add' : '💾 Save'}</button>
    </div>`, { small: true });
  bg.querySelector('#c_save').addEventListener('click', async () => {
    const payload = { name: bg.querySelector('#c_name').value.trim(), icon: bg.querySelector('#c_icon').value.trim() };
    if (!payload.name) return toast('Name is required', 'err');
    try {
      if (isNew) await api('/api/admin/categories', { method: 'POST', body: JSON.stringify(payload) });
      else await api('/api/admin/categories/' + c.id, { method: 'PUT', body: JSON.stringify(payload) });
      toast('Saved ✅', 'ok');
      close();
      vCategories(view);
    } catch (err) { toast(err.message, 'err'); }
  });
}

/* ============================== ADS ============================== */
const ZONES = [
  ['headerBanner', 'Header Banner — shown on every page below the header'],
  ['homeMid', 'Home Feed — inside the video grid (after 8 videos)'],
  ['belowPlayer', 'Watch Page — directly below the video player'],
  ['afterRelated', 'Watch Page — after the Related Videos section'],
  ['footerTop', 'Above Footer — shown on every page'],
];

async function vAds(view) {
  const a = await api('/api/admin/ads');
  view.innerHTML = `
  <div class="ads-note">
    💡 <b>How AdSense works here:</b> paste your <b>verification / Auto Ads snippet</b> below — it's automatically injected into the <span class="kbd">&lt;head&gt;</span> of every page.
    Fill <b>ads.txt</b> (live instantly at <span class="kbd">/ads.txt</span>). After Google approves your site, enable any <b>Ad Zone</b> and paste the ad-unit code from AdSense → it starts rendering immediately. Empty zones are invisible to visitors.
  </div>

  <div class="panel">
    <h2>🔗 AdSense Account</h2>
    <p class="muted">Connect your Google AdSense account</p>
    <div class="form">
      <div class="fg2" style="display:grid;gap:14px">
        <div class="fld"><label>PUBLISHER ID</label>
          <input id="ad_pub" value="${esc(a.adsensePublisherId || '')}" placeholder="ca-pub-1234567890123456"></div>
        <div class="fld"><label>VERIFICATION / AUTO-ADS SNIPPET (goes in &lt;head&gt; of all pages)</label>
          <textarea id="ad_head" rows="4" style="font-family:Consolas,monospace;font-size:12px" placeholder='<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossorigin="anonymous"></scr' + 'ipt>'>${esc(a.headSnippet || '')}</textarea></div>
        <div class="fld"><label>ADS.TXT CONTENT (served at /ads.txt)</label>
          <textarea id="ad_txt" rows="3" style="font-family:Consolas,monospace;font-size:12px" placeholder="google.com, pub-1234567890123456, DIRECT, f08c47fec0942fa0">${esc(a.adsTxt || '')}</textarea></div>
      </div>
    </div>
  </div>

  <div class="panel">
    <h2>📐 Ad Zones</h2>
    <p class="muted">Toggle a zone on and paste its ad-unit code</p>
    ${ZONES.map(([k, label]) => {
      const z = a.zones[k] || {};
      return `<div class="zone">
        <div class="zone-head"><b>${label}</b>
          <label class="switch"><input type="checkbox" data-zone="${k}" ${z.enabled ? 'checked' : ''}><span></span></label>
        </div>
        <textarea rows="3" data-code="${k}" placeholder="Paste your AdSense ad-unit code for this slot (optional while Auto Ads is on)">${esc(z.code || '')}</textarea>
      </div>`;
    }).join('')}
  </div>

  <button class="btn primary lg" id="adSave">💾 Save All Ad Settings</button>`;

  $('#adSave').addEventListener('click', async () => {
    const zones = {};
    ZONES.forEach(([k]) => {
      zones[k] = {
        enabled: $(`[data-zone="${k}"]`).checked,
        code: $(`[data-code="${k}"]`).value,
      };
    });
    try {
      await api('/api/admin/ads', {
        method: 'PUT',
        body: JSON.stringify({
          adsensePublisherId: $('#ad_pub').value.trim(),
          headSnippet: $('#ad_head').value,
          adsTxt: $('#ad_txt').value,
          zones,
        }),
      });
      toast('Ad settings saved ✅ — zones are live on the site now', 'ok');
    } catch (err) { toast(err.message, 'err'); }
  });
}

/* ============================== PAGES ============================== */
const PAGE_LIST = [
  ['about', 'ℹ️ About Us'],
  ['contact', '✉️ Contact'],
  ['privacy-policy', '🔒 Privacy Policy'],
  ['terms', '📜 Terms of Service'],
  ['dmca', '🛡️ DMCA'],
  ['disclaimer', '⚠️ Disclaimer'],
];

async function vPages(view) {
  if (!A.pages) A.pages = (await api('/api/admin/pages')).pages;
  const cur = A.curPage;
  const pg = A.pages[cur] || { title: '', content: '' };
  view.innerHTML = `
  <div class="panel">
    <h2>📄 Website Pages</h2>
    <p class="muted">Edit the content of your static pages. These pages are <b>essential for AdSense approval</b>, so keep them complete and professional.</p>
    <div class="pages-lay">
      <div class="p-list" id="pList">
        ${PAGE_LIST.map(([k, n]) => `<button data-p="${k}" class="${k === cur ? 'on' : ''}">${n}</button>`).join('')}
      </div>
      <div class="p-edit">
        <div class="row">
          <input id="pg_title" value="${esc(pg.title)}" maxlength="200" placeholder="Page title">
          <button class="btn primary" id="pg_save">💾 Save Page</button>
        </div>
        <textarea id="pg_content" spellcheck="false">${esc(pg.content)}</textarea>
        <p class="hint2">HTML is allowed: <span class="kbd">&lt;h3&gt;</span> <span class="kbd">&lt;p&gt;</span> <span class="kbd">&lt;ul&gt;&lt;li&gt;</span> <span class="kbd">&lt;b&gt;</span> <span class="kbd">&lt;a href&gt;</span> — live at <a href="/page?p=${cur}" target="_blank" style="color:#a58cff">/page?p=${cur} ↗</a></p>
      </div>
    </div>
  </div>`;

  $('#pList').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-p]');
    if (!b || b.dataset.p === A.curPage) return;
    A.curPage = b.dataset.p;
    vPages(view);
  });
  $('#pg_save').addEventListener('click', async () => {
    try {
      await api('/api/admin/pages/' + A.curPage, {
        method: 'PUT',
        body: JSON.stringify({ title: $('#pg_title').value.trim(), content: $('#pg_content').value }),
      });
      A.pages[A.curPage].title = $('#pg_title').value.trim();
      A.pages[A.curPage].content = $('#pg_content').value;
      toast('Page saved ✅', 'ok');
    } catch (err) { toast(err.message, 'err'); }
  });
}

/* ============================== MESSAGES ============================== */
async function vMessages(view) {
  const d = await api('/api/admin/messages');
  const msgs = d.messages || [];
  view.innerHTML = `
  <div class="toolbar">
    <span class="count">${msgs.length} message${msgs.length === 1 ? '' : 's'} · ${msgs.filter((m) => !m.read).length} unread</span>
    <span class="muted">Sent via the Contact page form</span>
  </div>
  <div id="mwrap">
    ${msgs.map((m) => `<div class="msg-card ${m.read ? '' : 'unread'}">
      <div class="msg-head">
        <b>${m.read ? '' : '🔵 '}${esc(m.name)}</b>
        <a href="mailto:${esc(m.email)}">${esc(m.email)}</a>
        <span class="date">${fmtD(m.date)}</span>
      </div>
      <p>${esc(m.message)}</p>
      <div class="msg-acts">
        <button class="btn sm" data-toggle="${m.id}">${m.read ? 'Mark unread' : '✔ Mark read'}</button>
        <button class="btn sm" ><a href="mailto:${esc(m.email)}" style="text-decoration:none">↩ Reply</a></button>
        <button class="btn sm danger" data-del="${m.id}">🗑 Delete</button>
      </div>
    </div>`).join('') || '<div class="panel"><div class="empty-rows">📭 No messages yet. Visitors can reach you from the <a href="/page?p=contact" target="_blank" style="color:#a58cff">Contact page</a>.</div></div>'}
  </div>`;

  $('#mwrap').addEventListener('click', async (e) => {
    const tog = e.target.closest('[data-toggle]');
    const del = e.target.closest('[data-del]');
    if (tog) {
      const m = msgs.find((x) => x.id === tog.dataset.toggle);
      try {
        await api('/api/admin/messages/' + m.id, { method: 'PUT', body: JSON.stringify({ read: !m.read }) });
        vMessages(view); refreshBadges();
      } catch (err) { toast(err.message, 'err'); }
    }
    if (del) {
      const ok = await confirmBox('Delete message?', 'This message will be permanently removed.', 'Delete');
      if (!ok) return;
      try {
        await api('/api/admin/messages/' + del.dataset.del, { method: 'DELETE' });
        toast('Message deleted', 'ok');
        vMessages(view); refreshBadges();
      } catch (err) { toast(err.message, 'err'); }
    }
  });
}

/* ============================== SETTINGS ============================== */
async function vSettings(view) {
  const { settings: s } = await api('/api/admin/settings');
  view.innerHTML = `
  <div class="panel">
    <h2>🏷️ Branding</h2>
    <p class="muted">Site identity shown in the header, footer and browser tab</p>
    <div class="form"><div class="fg2">
      <div class="fld"><label>LOGO TEXT</label><input id="s_logoText" value="${esc(s.logoText)}" maxlength="30"></div>
      <div class="fld"><label>LOGO ACCENT (gradient part)</label><input id="s_logoAccent" value="${esc(s.logoAccent)}" maxlength="10"></div>
      <div class="fld span2"><label>SITE NAME</label><input id="s_siteName" value="${esc(s.siteName)}" maxlength="60"></div>
      <div class="fld span2"><label>TAGLINE (footer description)</label><textarea id="s_tagline" rows="2" maxlength="300">${esc(s.tagline)}</textarea></div>
      <div class="fld"><label>CONTACT EMAIL</label><input id="s_contactEmail" value="${esc(s.contactEmail)}" maxlength="120"></div>
      <div class="fld"><label>VIDEOS PER PAGE</label><input type="number" min="4" max="100" id="s_vpp" value="${+s.videosPerPage || 20}"></div>
    </div></div>
  </div>

  <div class="panel">
    <h2>📝 Site Texts</h2>
    <p class="muted">Notices, disclaimers and other editable texts</p>
    <div class="form"><div class="fg2" style="display:grid;gap:14px">
      <div class="fld"><label>TOP NOTICE BAR <span style="color:var(--muted2)">(optional — shown under header on all pages, leave empty to hide)</span></label>
        <input id="s_headerNotice" value="${esc(s.headerNotice || '')}" maxlength="200" placeholder="e.g. 🔥 New videos added daily!"></div>
      <div class="fld"><label>PLAYER NOTICE (watch page, yellow bar)</label>
        <input id="s_playerNotice" value="${esc(s.playerNotice || '')}" maxlength="200" placeholder="e.g. ⚠️ If an ad appears, press Back and tap Play again."></div>
      <div class="fld"><label>COPYRIGHT LINE</label><input id="s_copy" value="${esc(s.footerCopyright)}" maxlength="200"></div>
      <div class="fld"><label>FOOTER DISCLAIMER (small italic text)</label><textarea id="s_disc" rows="2" maxlength="400">${esc(s.footerDisclaimer)}</textarea></div>
    </div></div>
  </div>

  <div class="panel">
    <h2>🔎 SEO</h2>
    <p class="muted">Default meta tags for the home page (video pages get their own automatically)</p>
    <div class="form"><div class="fg2" style="display:grid;gap:14px">
      <div class="fld"><label>META TITLE</label><input id="s_seoTitle" value="${esc(s.seo.title)}" maxlength="120"></div>
      <div class="fld"><label>META DESCRIPTION</label><textarea id="s_seoDesc" rows="2" maxlength="300">${esc(s.seo.description)}</textarea></div>
      <div class="fld"><label>META KEYWORDS</label><input id="s_seoKeys" value="${esc(s.seo.keywords)}" maxlength="300"></div>
      <div class="fld"><label>OG IMAGE URL <span style="color:var(--muted2)">(social share preview)</span></label><input id="s_seoOg" value="${esc(s.seo.ogImage || '')}" maxlength="300" placeholder="https://…/cover.jpg"></div>
    </div></div>
  </div>

  <button class="btn primary lg" id="s_save">💾 Save Settings</button>

  <div class="panel" style="margin-top:18px">
    <h2>🔐 Change Admin Password</h2>
    <p class="muted">Keep your admin panel secure</p>
    <div class="form"><div class="fg2" style="display:grid;gap:14px;max-width:520px">
      <div class="fld"><label>CURRENT PASSWORD</label><input type="password" id="p_cur" autocomplete="current-password"></div>
      <div class="fld"><label>NEW PASSWORD (min 6 characters)</label><input type="password" id="p_new" autocomplete="new-password"></div>
      <div class="fld"><label>CONFIRM NEW PASSWORD</label><input type="password" id="p_conf" autocomplete="new-password"></div>
    </div></div>
    <div style="margin-top:16px"><button class="btn danger" id="p_save">🔑 Update Password</button></div>
  </div>

  <div class="panel">
    <h2>🗄️ Data & Backup</h2>
    <p class="muted">All content lives in <span class="kbd">data/db.json</span></p>
    <div class="q-actions">
      <a class="btn" href="/api/admin/settings" target="_blank">Raw settings JSON ↗</a>
      <a class="btn" href="/sitemap.xml" target="_blank">View sitemap.xml ↗</a>
      <a class="btn" href="/ads.txt" target="_blank">View ads.txt ↗</a>
      <a class="btn" href="/robots.txt" target="_blank">View robots.txt ↗</a>
    </div>
  </div>`;

  $('#s_save').addEventListener('click', async () => {
    try {
      await api('/api/admin/settings', {
        method: 'PUT',
        body: JSON.stringify({
          logoText: $('#s_logoText').value.trim(),
          logoAccent: $('#s_logoAccent').value.trim(),
          siteName: $('#s_siteName').value.trim(),
          tagline: $('#s_tagline').value,
          contactEmail: $('#s_contactEmail').value.trim(),
          videosPerPage: +$('#s_vpp').value || 20,
          headerNotice: $('#s_headerNotice').value,
          playerNotice: $('#s_playerNotice').value,
          footerCopyright: $('#s_copy').value,
          footerDisclaimer: $('#s_disc').value,
          seo: {
            title: $('#s_seoTitle').value.trim(),
            description: $('#s_seoDesc').value.trim(),
            keywords: $('#s_seoKeys').value.trim(),
            ogImage: $('#s_seoOg').value.trim(),
          },
        }),
      });
      toast('Settings saved ✅ — live on the site now', 'ok');
    } catch (err) { toast(err.message, 'err'); }
  });

  $('#p_save').addEventListener('click', async () => {
    const cur = $('#p_cur').value, nw = $('#p_new').value, cf = $('#p_conf').value;
    if (nw !== cf) return toast('New passwords do not match', 'err');
    try {
      await api('/api/admin/password', { method: 'PUT', body: JSON.stringify({ current: cur, next: nw }) });
      toast('Password updated 🔑', 'ok');
      $('#p_cur').value = $('#p_new').value = $('#p_conf').value = '';
    } catch (err) { toast(err.message, 'err'); }
  });
}

/* ------------------------------ boot ------------------------------
   Order is strict:
   1. show ONLY the session-check loader
   2. migrate any old "forever" token into a per-session token
   3. if a token exists → verify it with the server
        → valid:   show ONLY the dashboard
        → invalid: clear it, show ONLY the login screen
   4. no token → show ONLY the login screen
   The dashboard can never be visible without a verified session.
------------------------------------------------------------------- */
(async function init() {
  showScreen('boot');
  try {
    // migrate legacy localStorage token (from before keep-me existed)
    const legacyRemember = localStorage.getItem('tp_remember');
    const legacyToken = localStorage.getItem('tp_admin');
    if (legacyToken && !legacyRemember) {
      sessionStorage.setItem('tp_admin', legacyToken);
      localStorage.removeItem('tp_admin');
    }
    A.token = sessionStorage.getItem('tp_admin') || localStorage.getItem('tp_admin') || '';

    if (A.token) {
      try {
        await api('/api/admin/stats'); // throws on 401 → logout() shows login
        enterApp();
        return;
      } catch (e) {
        /* invalid/expired session — fall through to the login screen */
      }
    }
  } catch (e) {
    console.error('Init error:', e);
  }
  showScreen('login');
  setTimeout(() => { try { $('#loginPass').focus(); } catch (e) {} }, 120);
})();
